<?php
require_once 'db.php';

echo "<h2>Shafa Data Synchronization Tool v3</h2>";

try {
    // 1. Ensure 'specialty' column exists
    $columnCheck = $conn->query("SHOW COLUMNS FROM doctors LIKE 'specialty'");
    if ($columnCheck->rowCount() == 0) {
        $conn->exec("ALTER TABLE doctors ADD COLUMN specialty VARCHAR(100) AFTER city");
    }

    // 2. Insert 10 NEW doctors across categories
    $specialties = ['Neurology', 'Cardiology', 'Pediatrics', 'Orthopedics', 'Gynecology', 'ENT', 'Psychiatry', 'Urology', 'Dentistry', 'Gastroenterology'];
    $stmt = $conn->prepare("INSERT INTO doctors (name, experience, city, specialty, education, clinic_name, clinic_address, about, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $insertedCount = 0;
    foreach ($specialties as $index => $spec) {
        $name = "Dr. " . $spec . " Expert";
        $check = $conn->prepare("SELECT id FROM doctors WHERE name = ?");
        $check->execute([$name]);
        if ($check->rowCount() == 0) {
            $stmt->execute([
                $name, 10 + $index, "City Central", $spec, "MBBS, MD (" . $spec . ")", "Shafa Specialist Clinic", "Health Street, Block A", "Top rated professional specialized in " . $spec . ".", "+923001234567"
            ]);
            $insertedCount++;
        }
    }
    echo "<p style='color:green;'>✅ Doctors synced.</p>";

    // 3. Add Dummy Reviews for diversity
    $conn->exec("DELETE FROM reviews"); // Clear for fresh seed

    $reviewData = [
        [1, 'Ali Raza', 'Excellent experience, very professional.', 5],
        [1, 'Hina Malik', 'Wait time was a bit long but the treatment was great.', 4],
        [2, 'Zainab Bibi', 'Very knowledgeable and kind doctor.', 5],
        [3, 'Usman Khan', 'Great with skin, highly recommended.', 5],
        [4, 'Ahmed Khan', 'Very professional neurologist, solved my migraines.', 5],
        [5, 'Sara Ahmed', 'Experienced cardiologist, highly trust him.', 5],
        [6, 'Fatima Noor', 'Wonderful with kids, my son felt very comfortable.', 5]
    ];

    $revStmt = $conn->prepare("INSERT INTO reviews (doctor_id, patient_name, comment, rating) VALUES (?, ?, ?, ?)");
    foreach ($reviewData as $rev) {
        // Only insert if doctor exists
        $checkDoc = $conn->prepare("SELECT id FROM doctors WHERE id = ?");
        $checkDoc->execute([$rev[0]]);
        if ($checkDoc->rowCount() > 0) {
            $revStmt->execute($rev);
        }
    }
    echo "<p style='color:green;'>✅ Reviews seeded successfully.</p>";

    echo "<h3>System is now fully ready with Reviews!</h3>";
    echo "<p>Visit <a href='index.php'>Home Page</a> then view any doctor profile.</p>";

}
catch (PDOException $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
