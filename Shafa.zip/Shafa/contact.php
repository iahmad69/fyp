<?php
require_once 'db.php';
$pageTitle = "Contact Us";
include 'includes/header.php';

$successMsg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $to = "shafahealthcare.pk@gmail.com";
    $name = $_POST['name'] ?? 'Anonymous';
    $email = $_POST['email'] ?? 'No Email';
    $subject = "Shafa Contact: " . ($_POST['subject'] ?? 'No Subject');
    $message = $_POST['message'] ?? '';
    
    $headers = "From: " . $email;
    
    // Simulate sending or use mail() if server configured
    @mail($to, $subject, "Name: $name\nEmail: $email\n\nMessage:\n$message", $headers);
    
    $successMsg = "Thank you, $name! Your message has been sent to our team.";
}
?>

<style>
    /* Premium Contact Hero */
    .contact-hero {
        padding: 6rem 0 4rem;
        background: radial-gradient(at top right, rgba(132, 94, 194, 0.15) 0%, #fff 80%),
                    radial-gradient(at bottom left, rgba(0, 140, 203, 0.1) 0%, #fff 80%);
        border-radius: 0 0 60px 60px;
        text-align: center;
        margin-bottom: 4rem;
    }
    .contact-hero h1 {
        font-size: 3.5rem;
        font-weight: 800;
        letter-spacing: -2px;
        color: #2d3436;
        margin-bottom: 1rem;
    }
    .contact-hero p {
        color: #64748b;
        font-size: 1.2rem;
        max-width: 650px;
        margin: 0 auto;
    }

    /* Contact Page Layout */
    .contact-grid {
        display: grid;
        grid-template-columns: 1fr 1.5fr;
        gap: 4rem;
        margin-top: 2rem;
        align-items: start;
    }

    /* Info Cards */
    .contact-info-stack {
        display: flex;
        flex-direction: column;
        gap: 2rem;
    }
    .contact-info-card {
        background: white;
        padding: 2.5rem;
        border-radius: 24px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.03);
        border: 1px solid #f1f5f9;
    }
    .contact-method {
        display: flex;
        gap: 20px;
        margin-bottom: 2rem;
        align-items: center;
    }
    .contact-method:last-child { margin-bottom: 0; }
    .contact-icon {
        background: #f8fafc;
        width: 55px;
        height: 55px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        flex-shrink: 0;
        border: 1px solid #f1f5f9;
    }
    .method-details h4 {
        font-size: 0.85rem;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 2px;
    }
    .method-details p {
        font-weight: 700;
        color: #1e293b;
        font-size: 1.1rem;
    }

    .support-banner {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        padding: 2.5rem;
        border-radius: 24px;
        color: white;
        text-align: center;
        box-shadow: 0 10px 20px rgba(132, 94, 194, 0.2);
    }
    .support-banner h3 { margin-bottom: 1rem; font-size: 1.5rem; }
    .support-banner p { opacity: 0.9; font-size: 0.95rem; line-height: 1.6; }

    /* Contact Form Card */
    .contact-form-card {
        background: white;
        padding: 4rem;
        border-radius: 30px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.04);
        border: 1px solid #f1f5f9;
        position: relative;
        overflow: hidden;
    }
    .contact-form-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 6px;
        background: linear-gradient(to right, var(--primary), var(--secondary));
    }
    .contact-form-card h3 {
        margin-bottom: 2.5rem;
        font-size: 2rem;
        font-weight: 800;
        letter-spacing: -1px;
        color: #1e293b;
    }

    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
    }
    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.8rem;
        margin-bottom: 2rem;
    }
    .form-group label {
        font-size: 0.95rem;
        font-weight: 600;
        color: #475569;
    }
    .form-input {
        width: 100%;
        padding: 1.2rem 1.5rem;
        border-radius: 15px;
        border: 2px solid #f1f5f9;
        outline: none;
        background: #f8fafc;
        font-size: 1rem;
        transition: var(--transition);
        font-family: inherit;
    }
    .form-input:focus {
        border-color: var(--primary);
        background: white;
        box-shadow: 0 0 0 4px rgba(132, 94, 194, 0.1);
    }
    textarea.form-input {
        height: 180px;
        resize: none;
    }

    /* Core Responsiveness for Contact Grid */
    @media (max-width: 992px) {
        .contact-grid {
            grid-template-columns: 1fr;
            gap: 3rem;
        }
        .contact-form-card {
            order: -1; /* Form comes first on mobile */
        }
    }
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
            gap: 0;
        }
        .contact-form-card {
            padding: 2.5rem 1.5rem;
        }
    }
</style>

<section class="contact-hero">
    <div class="container">
        <h1>Contact Us</h1>
        <p>Have questions or need assistance? Our team is here to help you connect with the right care.</p>
    </div>
</section>

<div class="container" style="margin-bottom: 8rem;">
    <?php if ($successMsg): ?>
    <div style="background: #f0fdf4; color: #166534; padding: 1.5rem; border-radius: 20px; border: 1px solid #bbf7d0; margin-bottom: 3rem; text-align: center; font-weight: 700; box-shadow: 0 4px 10px rgba(22, 101, 52, 0.05);">
        ✅ <?php echo $successMsg; ?>
    </div>
    <?php endif; ?>

    <div class="contact-grid">
        <!-- Contact Information -->
        <div class="contact-info-stack">
            <div class="contact-info-card">
                <h3 style="margin-bottom: 2.5rem; color: var(--primary); font-size: 1.6rem; font-weight: 800; letter-spacing: -0.5px;">Get in Touch</h3>
                
                <div class="contact-method">
                    <div class="contact-icon" style="background: #f0f7ff; color: #008ccb;">📞</div>
                    <div class="method-details">
                        <h4>Phone</h4>
                        <p>+92 (300) 123-4567</p>
                    </div>
                </div>

                <div class="contact-method">
                    <div class="contact-icon" style="background: #fdf2f8; color: #d65db1;">📧</div>
                    <div class="method-details">
                        <h4>Email</h4>
                        <p>shafahealthcare.pk@gmail.com
</p>
                    </div>
                </div>

                <div class="contact-method">
                    <div class="contact-icon" style="background: #f0fdf4; color: #00897b;">📍</div>
                    <div class="method-details">
                        <h4>Location</h4>
                        <p>Gulberg III, Lahore, Pakistan</p>
                    </div>
                </div>
            </div>

            <div class="support-banner">
                <h3>Available 24/7</h3>
                <p>Our customer support team is available around the clock to assist with your bookings and inquiries.</p>
            </div>
        </div>

        <!-- Contact Form -->
        <div class="contact-form-card">
            <h3>Send us a Message</h3>
            <form action="" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="name" placeholder="John Doe" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" placeholder="john@example.com" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Subject</label>
                    <input type="text" name="subject" placeholder="Appointment Inquiry" class="form-input" required>
                </div>

                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" placeholder="Tell us how we can help..." class="form-input" required></textarea>
                </div>

                <button type="submit" class="btn" style="padding: 1.4rem; font-size: 1.1rem; border-radius: 18px; width: 100%; letter-spacing: 0.5px;">Send Secure Message &rarr;</button>
            </form>
        </div>
    </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
