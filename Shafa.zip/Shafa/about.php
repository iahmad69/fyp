<?php
require_once 'db.php';
$pageTitle = "About Us";
include 'includes/header.php';
?>

<div class="container">
    <div class="info-page">
        <h1 style="font-size: 3.5rem; letter-spacing: -2px; margin-bottom: 2rem; color: var(--text-primary);">Simplifying <span style="color:var(--primary);">Healthcare.</span></h1>
        <p style="font-size: 1.3rem; margin-bottom: 3rem; font-weight: 300; line-height: 1.7;">Shafa is a premier medical directory platform dedicated to bringing healthcare closer to you. We empower patients with transparent information and direct access to top-tier medical specialists.</p>
        
        <div class="profile-section">
            <h2>Our Vision</h2>
            <p style="font-size: 1.1rem; opacity: 0.9;">We envision a world where finding the right care is effortless. By combining premium design with robust technology, Shafa provides a mobile-first experience that prioritizes your health and time.</p>
        </div>

        <div class="profile-section">
            <h2>Core Capabilities</h2>
            <p style="font-size: 1.1rem; opacity: 0.9;">This MVP project demonstrates a state-of-the-art healthcare interface, featuring:</p>
            <ul style="margin-top: 1.5rem; margin-left:1.5rem; display: flex; flex-direction: column; gap: 0.8rem; font-size: 1.05rem; opacity: 0.9;">
                <li>Verified Professional Directory</li>
                <li>Comprehensive Educational Backgrounds</li>
                <li>Direct Clinical Contact System</li>
                <li>Premium, Responsive Visual Language</li>
            </ul>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
