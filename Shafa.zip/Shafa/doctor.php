<?php
require_once 'db.php';

$doctor_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($doctor_id <= 0) {
    header("Location: doctors.php");
    exit;
}

// Fetch Doctor Details
$stmt = $conn->prepare("SELECT * FROM doctors WHERE id = ?");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch();

if (!$doctor) {
    $pageTitle = "Doctor Not Found";
    include 'includes/header.php';
    echo "<div class='container' style='text-align:center; padding:10rem 0;'><h1>Doctor Not Found</h1><a href='doctors.php' class='btn'>Back to Directory</a></div>";
    include 'includes/footer.php';
    exit;
}

$pageTitle = $doctor['name'];
include 'includes/header.php';

// Fetch Reviews & Calculate Average
$reviewStmt = $conn->prepare("SELECT * FROM reviews WHERE doctor_id = ? ORDER BY created_at DESC LIMIT 4");
$reviewStmt->execute([$doctor_id]);
$reviews = $reviewStmt->fetchAll();

$totalReviews = count($reviews);
$avgRating = 0;
if ($totalReviews > 0) {
    $sum = 0;
    foreach ($reviews as $r)
        $sum += $r['rating'];
    $avgRating = round($sum / $totalReviews, 1);
}
?>

<div class="container" style="padding: 3rem 0;">
    <a href="doctors.php" style="text-decoration: none; color: var(--text-secondary); font-size: 0.95rem; font-weight: 500; display: inline-flex; align-items: center; gap: 8px;">
        <span style="font-size: 1.2rem;">&larr;</span> Back to Directory
    </a>

    <div class="profile-container">
        <!-- Main Content Column -->
        <main class="profile-main-content">
            
            <div class="profile-section profile-header" style="padding: 2.5rem; border: none; box-shadow: none; background: transparent;">
                <div class="profile-header-content" style="display: flex; gap: 3rem; align-items: center;">
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 1rem;">
                        <div style="position: relative;">
                            <img src="/Shafa/assets/images/<?php echo $doctor['profile_image']; ?>" 
                                 alt="<?php echo $doctor['name']; ?>" 
                                 style="width: 220px; height: 220px; border-radius: 50px; box-shadow: var(--shadow-md); object-fit: cover; border: 5px solid white;">
                            <div style="position: absolute; bottom: 15px; right: 15px; background: #2ecc71; width: 25px; height: 25px; border-radius: 50%; border: 3px solid white; box-shadow: var(--shadow-sm);"></div>
                        </div>
                        <span class="badge" style="background: #2ecc71; color: black; font-weight: 700; width: 180px; text-align: center; border-radius: 10px; padding: 8px 12px; font-size: 0.85rem; box-shadow: var(--shadow-sm);">Verified Professional</span>
                    </div>
                    
                    <div style="flex: 1;">
                        <h1 style="font-size: 3.2rem; font-weight: 800; color: #1a1a1a; letter-spacing: -1.5px; margin-bottom: 0.5rem;"><?php echo $doctor['name']; ?></h1>
                        
                        <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 20px; margin-bottom: 2rem;">
                            <p style="font-size: 1.1rem; color: #5a5a5a;">
                                Specialist in <span style="color: var(--primary); font-weight: 700;"><?php echo htmlspecialchars($doctor['specialty'] ?? 'Medicine'); ?></span>
                            </p>
                            <?php if ($totalReviews > 0): ?>
                                <div style="display: flex; align-items: center; gap: 6px; background: #fff8e6; padding: 6px 14px; border-radius: 12px; border: 1px solid #ffe8cc;">
                                    <span style="color: #f39c12; font-weight: 700;">★ <?php echo $avgRating; ?></span>
                                    <span style="color: #94a3b8; font-size: 0.85rem;">(<?php echo $totalReviews; ?> Reviews)</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div style="margin-top: 1rem;">
                            <h4 style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1.5px; color: #94a3b8; margin-bottom: 0.8rem; font-weight: 700;">Education & Credentials</h4>
                            <div class="badge-list" style="gap: 10px;">
                                <?php
                                $edu_items = explode(',', $doctor['education']);
                                foreach ($edu_items as $item): ?>
                                    <span class="badge" style="background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; font-weight: 500;"><?php echo trim($item); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Clinic Section (Multiple Locations) -->
            <?php
            $locStmt = $conn->prepare("SELECT * FROM doctor_locations WHERE doctor_id = ? ORDER BY id ASC");
            $locStmt->execute([$doctor['id']]);
            $locations = $locStmt->fetchAll();
            
            if (!empty($locations)):
                foreach ($locations as $loc):
            ?>
            <div class="profile-section">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2>Clinical Practice</h2>
                    <span class="badge" style="background: #eef2ff; color: #4338ca;">Clinic Fee: Rs. <?php echo number_format($loc['fee'] ?? 0, 0); ?></span>
                </div>
                <div style="display: flex; gap: 15px; align-items: center; margin-bottom: 1rem;">
                    <span style="font-size: 2rem;">🏢</span>
                    <div>
                        <h3 style="font-size: 1.4rem; color: #333;"><?php echo htmlspecialchars($loc['location_name']); ?></h3>
                    </div>
                </div>
                <div style="background: #f8faff; padding: 1.5rem; border-radius: 12px; border: 1px dashed #d1d9e6;">
                    <p style="color: var(--text-secondary); white-space: pre-line; letter-spacing: 0.3px; margin-bottom: 1rem;">
                        <?php echo htmlspecialchars($loc['address']); ?>
                    </p>
                    <div style="display: flex; align-items: center; gap: 8px; color: var(--primary); font-size: 0.9rem; font-weight: 500;">
                        <span>🕒</span> Clinic Hours: <?php echo htmlspecialchars($loc['schedule'] ?? 'TBD'); ?>
                    </div>
                </div>
            </div>
            <?php 
                endforeach;
            endif; 
            ?>

            <!-- Video Consultation Section -->
            <?php if (isset($doctor['video_consultation']) && $doctor['video_consultation']): ?>
            <div class="profile-section" style="background: linear-gradient(135deg, #f0fdf4 0%, #ffffff 100%); border: 1px solid #bbf7d0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <h2 style="color: #166534; margin: 0;">📹 Video Consultation</h2>
                    <span class="badge" style="background: #166534; color: white;">Video Fee: Rs. <?php echo number_format($doctor['video_fee'] ?? 0, 0); ?></span>
                </div>
                <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #dcfce7;">
                    <p style="color: #374151; font-size: 1rem;">
                        This doctor is available for online video consultations. You can book a virtual session from the comfort of your home.
                    </p>
                    <div style="margin-top: 1rem; display: flex; flex-direction: column; gap: 10px;">
                        <div style="display: flex; align-items: center; gap: 8px; color: #166534; font-size: 0.95rem; font-weight: 600;">
                            <span>🕒</span> Available: <?php echo htmlspecialchars($doctor['video_hours'] ?? 'TBD'); ?>
                        </div>
                        <div style="display: flex; gap: 10px; margin-top: 5px;">
                            <span style="background: #f0fdf4; padding: 5px 12px; border-radius: 6px; font-size: 0.85rem; color: #166534;">✓ Instant Connection</span>
                            <span style="background: #f0fdf4; padding: 5px 12px; border-radius: 6px; font-size: 0.85rem; color: #166534;">✓ Secure & Private</span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Reviews Section -->
            <div class="profile-section">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                    <h2>Patient Reviews</h2>
                    <?php if ($totalReviews > 0): ?>
                        <span style="color: var(--text-secondary); font-size: 0.95rem;">Average Score: <strong><?php echo $avgRating; ?>/5</strong></span>
                    <?php
endif; ?>
                </div>

                <?php if (empty($reviews)): ?>
                    <div style="text-align: center; padding: 2rem; background: #fdfdfd; border-radius: 12px; border: 1px solid var(--border-soft);">
                        <p style="color: var(--text-secondary);">No reviews yet. Be the first to share your experience!</p>
                    </div>
                <?php
else: ?>
                    <?php foreach ($reviews as $rev): ?>
                        <div class="review-card">
                            <div class="review-header">
                                <div class="patient-info">
                                    <div class="avatar-circle"><?php echo strtoupper(substr($rev['patient_name'], 0, 1)); ?></div>
                                    <div>
                                        <h4 style="font-size: 1rem; color: #333;"><?php echo $rev['patient_name']; ?></h4>
                                        <span class="review-date"><?php echo date('M d, Y', strtotime($rev['created_at'])); ?></span>
                                    </div>
                                </div>
                                <div class="stars">
                                    <?php for ($i = 0; $i < 5; $i++)
            echo($i < $rev['rating']) ? '★' : '☆'; ?>
                                </div>
                            </div>
                            <p style="color: var(--text-secondary); line-height: 1.6; font-style: italic;">
                                "<?php echo $rev['comment']; ?>"
                            </p>
                        </div>
                    <?php
    endforeach; ?>
                <?php
endif; ?>
            </div>

            <!-- About Section -->
            <div class="profile-section">
                <h2>About the Professional</h2>
                <p style="white-space: pre-line; font-size: 1.1rem; line-height: 1.9; color: var(--text-secondary);">
                    <?php echo $doctor['about']; ?>
                </p>
            </div>
        </main>

        <!-- Sidebar Column -->
        <aside class="profile-sidebar">
            <div class="sidebar-card">
                <div style="background: #f8faff; border-radius: 12px; padding: 1.5rem; border: 1px solid var(--border-soft);">
                    <div class="stat-item" style="border-bottom: 1px solid rgba(0,0,0,0.05); padding-bottom: 1rem; margin-bottom: 1rem;">
                        <div class="stat-icon">🎓</div>
                        <div class="stat-info">
                            <h4>Specialty</h4>
                            <p><?php echo htmlspecialchars($doctor['specialty'] ?? 'General'); ?></p>
                        </div>
                    </div>
                    <?php if ($totalReviews > 0): ?>
                    <div class="stat-item" style="border-bottom: 1px solid rgba(0,0,0,0.05); padding-bottom: 1rem; margin-bottom: 1rem;">
                        <div class="stat-icon">⭐</div>
                        <div class="stat-info">
                            <h4>Rating</h4>
                            <p><?php echo $avgRating; ?> / 5.0</p>
                        </div>
                    </div>
                    <?php
endif; ?>
                    <div class="stat-item">
                        <div class="stat-icon">⌛</div>
                        <div class="stat-info">
                            <h4>Experience</h4>
                            <p><?php echo $doctor['experience']; ?> Years +</p>
                        </div>
                    </div>
                    <?php if ($totalReviews > 0): ?>
                    <div class="stat-item" style="border-bottom: none; padding-bottom: 0; margin-bottom: 0;">
                        <div class="stat-icon">❤️</div>
                        <div class="stat-info">
                            <h4>Satisfaction</h4>
                            <p><?php echo round(($avgRating / 5) * 100); ?>%</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <div style="margin-top: 2rem;">
                    <a href="tel:<?php echo $doctor['phone']; ?>" class="btn btn-call" style="width: 100%; text-align: center; padding: 1.2rem; font-size: 1.1rem; display: block; border-radius: 15px;">
                        Call Now 📞
                    </a>
                </div>
            </div>

            <div class="sidebar-card" style="background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border: none;">
                <h4 style="margin-bottom: 1rem; font-size: 1rem; opacity: 0.9;">Direct Booking</h4>
                <p style="font-size: 0.9rem; line-height: 1.6; opacity: 0.9;">Contact the clinic directly to schedule your appointment or inquire about visiting hours.</p>
            </div>
        </aside>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
