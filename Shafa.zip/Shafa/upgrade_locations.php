<?php
require_once 'db.php';

echo "<h2>Upgrading System for Multiple Locations...</h2>";

try {
    // 1. Create doctor_locations table
    $sql = "CREATE TABLE IF NOT EXISTS doctor_locations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        doctor_id INT NOT NULL,
        location_name VARCHAR(255) NOT NULL,
        address TEXT NOT NULL,
        fee DECIMAL(10,2) DEFAULT 0.00,
        schedule VARCHAR(255) DEFAULT 'Mon-Fri: 9AM - 5PM',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "<p style='color:green;'>✅ Table 'doctor_locations' created/verified.</p>";

    // 2. Migrate existing clinic data from doctors table if not already migrated
    $doctors = $conn->query("SELECT id, clinic_name, clinic_address, clinic_fee, clinic_hours FROM doctors WHERE clinic_name IS NOT NULL AND clinic_name != ''")->fetchAll();
    
    foreach ($doctors as $doc) {
        // Check if this primary location is already in the locations table
        $check = $conn->prepare("SELECT id FROM doctor_locations WHERE doctor_id = ? AND location_name = ?");
        $check->execute([$doc['id'], $doc['clinic_name']]);
        
        if (!$check->fetch()) {
            $insert = $conn->prepare("INSERT INTO doctor_locations (doctor_id, location_name, address, fee, schedule) VALUES (?, ?, ?, ?, ?)");
            $insert->execute([$doc['id'], $doc['clinic_name'], $doc['clinic_address'], $doc['clinic_fee'], $doc['clinic_hours']]);
            echo "<p style='color:blue;'>ℹ️ Migrated primary clinic for: Doctor ID " . $doc['id'] . "</p>";
        }
    }

    echo "<h3>System Upgrade Successful!</h3>";
    echo "<p>Next: I will update the Admin and Profile pages to support these multiple locations.</p>";

} catch (PDOException $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
