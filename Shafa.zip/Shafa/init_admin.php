<?php
require_once 'db.php';

// PASSWORDS UPDATED BY USER REQUEST
$new_admin_password = 'Marham@32!';

$new_editor_password = 'P@ssword32!';

echo "<h2>Shafa Admin Password Updater</h2>";

try {
    // 1. Ensure table exists
    $conn->exec("CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('Admin', 'Editor') DEFAULT 'Editor',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // 2. Update or Create Admin
    $adm_hash = password_hash($new_admin_password, PASSWORD_BCRYPT);
    $check = $conn->prepare("SELECT id FROM users WHERE username = 'admin'");
    $check->execute();
    if ($check->rowCount() > 0) {
        $conn->prepare("UPDATE users SET password = ? WHERE username = 'admin'")->execute([$adm_hash]);
        echo "<p style='color:green;'>✅ Admin password updated.</p>";
    }
    else {
        $conn->prepare("INSERT INTO users (username, password, role) VALUES ('admin', ?, 'Admin')")->execute([$adm_hash]);
        echo "<p style='color:green;'>✅ Admin account created.</p>";
    }

    // 3. Update or Create Editor
    $edt_hash = password_hash($new_editor_password, PASSWORD_BCRYPT);
    $check = $conn->prepare("SELECT id FROM users WHERE username = 'editor'");
    $check->execute();
    if ($check->rowCount() > 0) {
        $conn->prepare("UPDATE users SET password = ? WHERE username = 'editor'")->execute([$edt_hash]);
        echo "<p style='color:green;'>✅ Editor password updated.</p>";
    }
    else {
        $conn->prepare("INSERT INTO users (username, password, role) VALUES ('editor', ?, 'Editor')")->execute([$edt_hash]);
        echo "<p style='color:green;'>✅ Editor account created.</p>";
    }

    echo "<h3>Passwords have been synchronized!</h3>";
    echo "<p>You can now login here: <a href='admin_login.php'>Admin Login</a></p>";

}
catch (PDOException $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
