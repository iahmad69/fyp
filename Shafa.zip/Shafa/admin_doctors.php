<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: admin_login.php");
    exit;
}

require_once 'db.php';

// --- SELF REPAIR BLOCK ---
try {
    $columns = $conn->query("SHOW COLUMNS FROM doctors")->fetchAll(PDO::FETCH_COLUMN);
    $new_cols = [
        'video_consultation' => "TINYINT(1) DEFAULT 0",
        'clinic_fee' => "DECIMAL(10,2) DEFAULT 0.00",
        'video_fee' => "DECIMAL(10,2) DEFAULT 0.00",
        'clinic_hours' => "VARCHAR(255) DEFAULT 'Mon-Fri: 9AM - 5PM'",
        'video_hours' => "VARCHAR(255) DEFAULT 'Mon-Fri: 6PM - 9PM'",
        'ranking' => "INT DEFAULT 0",
        'status' => "TINYINT(1) DEFAULT 1"
    ];

    foreach ($new_cols as $col => $def) {
        if (!in_array($col, $columns)) {
            $conn->exec("ALTER TABLE doctors ADD $col $def");
        }
    }
} catch (Exception $e) {}
// -------------------------

$message = '';
$search = isset($_GET['q']) ? $_GET['q'] : '';

// Handle Delete (Admin Only)
if (isset($_GET['delete'])) {
    if ($_SESSION['role'] !== 'Admin') {
        $message = "Error: Only Admins can delete entries.";
    }
    else {
        $id = (int)$_GET['delete'];
        $stmt = $conn->prepare("DELETE FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        $message = "Doctor deleted successfully.";
    }
}

// Handle Add/Edit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_doctor'])) {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name = $_POST['name'];
    $specialty = $_POST['specialty'];
    $experience = $_POST['experience'];
    $city = $_POST['city'];
    $education = $_POST['education'];
    $clinic_name = $_POST['clinic_name'];
    $clinic_address = $_POST['clinic_address'];
    $about = $_POST['about'];
    $phone = $_POST['phone'];
    $video_consultation = isset($_POST['video_consultation']) ? 1 : 0;
    $clinic_fee = $_POST['clinic_fee'];
    $video_fee = $_POST['video_fee'];
    $clinic_hours = $_POST['clinic_hours'];
    $video_hours = $_POST['video_hours'];

    // Default image if new
    $profile_image = "doctor_placeholder.jpg";

    // If editing, keep old image unless new one uploaded
    if ($id > 0) {
        $stmt = $conn->prepare("SELECT profile_image FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        $profile_image = $stmt->fetchColumn() ?: "doctor_placeholder.jpg";
    }

    // Handle Image Upload
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $filename = $_FILES['profile_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {
            $newName = "doc_" . time() . "_" . $filename;
            $upload_dir = "assets/images/";
            if (!is_dir($upload_dir))
                mkdir($upload_dir, 0777, true);

            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_dir . $newName)) {
                $profile_image = $newName;
            }
        }
    }

    if ($id > 0) {
        $sql = "UPDATE doctors SET name=?, specialty=?, experience=?, city=?, phone=?, education=?, clinic_name=?, clinic_address=?, about=?, video_consultation=?, clinic_fee=?, video_fee=?, clinic_hours=?, video_hours=?, ranking=?, status=? WHERE id = ?";
        $params = [$name, $specialty, $experience, $city, $phone, $education, $clinic_name, $clinic_address, $about, $video_consultation, $clinic_fee, $video_fee, $clinic_hours, $video_hours, $_POST['ranking'], $_POST['status'], $id];
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $message = "Doctor updated successfully.";
    }
    else {
        $sql = "INSERT INTO doctors (name, specialty, experience, city, phone, profile_image, education, clinic_name, clinic_address, about, video_consultation, clinic_fee, video_fee, clinic_hours, video_hours, ranking, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $params = [$name, $specialty, $experience, $city, $phone, $profile_image, $education, $clinic_name, $clinic_address, $about, $video_consultation, $clinic_fee, $video_fee, $clinic_hours, $video_hours, $_POST['ranking'], $_POST['status']];
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        $message = "Doctor added successfully.";
    }
}

// Fetch Doctors with Search
$sql = "SELECT * FROM doctors WHERE 1=1 ";
$params = [];
if ($search) {
    $sql .= "AND (name LIKE ? OR specialty LIKE ? OR city LIKE ?) ";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}
$sql .= " ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$doctors = $stmt->fetchAll();

// Fetch single doctor if editing
$edit_doc = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM doctors WHERE id = ?");
    $stmt->execute([$id]);
    $edit_doc = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors - Shafa Admin</title>
    <link rel="stylesheet" href="/Shafa/assets/css/style.css">
    <style>
        body { display: flex; min-height: 100vh; background: #f0f2f5; }
        .admin-sidebar { width: 280px; background: white; border-right: 1px solid var(--border-soft); padding: 2rem; display: flex; flex-direction: column; }
        .admin-main { flex: 1; padding: 3rem; overflow-y: auto; }
        .nav-list { list-style: none; margin-top: 3rem; flex: 1; }
        .nav-list a { text-decoration: none; color: var(--text-secondary); display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; transition: var(--transition); }
        .nav-list a:hover, .nav-list a.active { background: var(--primary); color: white; }
        .form-card, .table-card { background: white; border-radius: 20px; padding: 2rem; box-shadow: var(--shadow-sm); border: 1px solid var(--border-soft); margin-bottom: 2rem; }
        .input-group { margin-bottom: 1.2rem; }
        .input-group label { display: block; margin-bottom: 0.5rem; font-size: 0.9rem; font-weight: 600; }
        .input-group input, .input-group select, .input-group textarea { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #ddd; font-family: inherit; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { text-align: left; padding: 12px; border-bottom: 1px solid #eee; font-size: 0.9rem; }
        .action-btn { padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 0.8rem; margin-right: 5px; color: white; }
        .btn-edit { background: #008CCB; }
        .btn-delete { background: #d63031; }
    </style>
</head>
<body class="fade-in">
    <div class="admin-sidebar">
        <a href="index.php" class="logo" style="text-decoration:none; color:var(--primary); font-size: 2rem; font-weight:700;">Shafa</a>
        <ul class="nav-list">
            <li><a href="admin_dashboard.php"><span>📊</span> Dashboard</a></li>
            <li><a href="admin_doctors.php" class="active"><span>👨‍⚕️</span> Manage Doctors</a></li>
            <li><a href="admin_reviews.php"><span>⭐</span> Manage Reviews</a></li>
        </ul>
        <div style="border-top:1px solid #eee; padding-top:2rem;">
            <a href="logout.php" style="color:#d63031; text-decoration:none; font-size:0.9rem;">Logout</a>
        </div>
    </div>

    <main class="admin-main">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2rem;">
            <h1>Manage Doctors</h1>
            <form method="GET" style="display:flex; gap:10px;">
                <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search doctors..." 
                       style="padding: 8px 15px; border-radius: 8px; border: 1px solid var(--border-soft); outline:none;">
                <button type="submit" class="btn" style="padding: 8px 15px; font-size:0.8rem;">Search</button>
            </form>
        </div>
        
        <?php if ($message): ?> <div style="background:#d4edda; color:#155724; padding:15px; border-radius:8px; margin-bottom:20px;"><?php echo $message; ?></div> <?php
endif; ?>

        <!-- Add/Edit Form -->
        <div class="form-card">
            <h3><?php echo $edit_doc ? 'Edit Doctor' : 'Add New Doctor'; ?></h3>
            <form method="POST" enctype="multipart/form-data" style="display:grid; grid-template-columns: 1fr 1fr; gap:1.5rem; margin-top:1.5rem;">
                <input type="hidden" name="id" value="<?php echo $edit_doc['id'] ?? ''; ?>">
                
                <div class="input-group" style="grid-column: span 2; display:flex; gap:20px; align-items:center;">
                    <?php if (isset($edit_doc['profile_image'])): ?>
                        <img src="assets/images/<?php echo $edit_doc['profile_image']; ?>" style="width:80px; height:80px; border-radius:15px; object-fit:cover;" onerror="this.src='https://via.placeholder.com/80?text=None';">
                    <?php
endif; ?>
                    <div style="flex:1;">
                        <label>Profile Picture</label>
                        <input type="file" name="profile_image" accept="image/*">
                    </div>
                </div>

                <div class="input-group"><label>Full Name</label><input type="text" name="name" value="<?php echo $edit_doc['name'] ?? ''; ?>" required></div>
                <div class="input-group"><label>Specialty</label><input type="text" name="specialty" value="<?php echo $edit_doc['specialty'] ?? ''; ?>" required></div>
                <div class="input-group"><label>Experience (Years)</label><input type="number" name="experience" value="<?php echo $edit_doc['experience'] ?? ''; ?>" required></div>
                <div class="input-group"><label>City</label><input type="text" name="city" value="<?php echo $edit_doc['city'] ?? ''; ?>" required></div>
                <div class="input-group"><label>Phone</label><input type="text" name="phone" value="<?php echo $edit_doc['phone'] ?? ''; ?>" required></div>
                <div class="input-group"><label>Clinic Name</label><input type="text" name="clinic_name" value="<?php echo $edit_doc['clinic_name'] ?? ''; ?>" required></div>
                
                <div class="input-group">
                    <label>Clinic Fee (Rs.)</label>
                    <input type="number" name="clinic_fee" value="<?php echo $edit_doc['clinic_fee'] ?? '0'; ?>" step="0.01" required>
                </div>
                <div class="input-group">
                    <label>Video Fee (Rs.)</label>
                    <input type="number" name="video_fee" value="<?php echo $edit_doc['video_fee'] ?? '0'; ?>" step="0.01" required>
                </div>
                
                <div class="input-group">
                    <label>Clinic Hours (e.g. Mon-Fri: 9AM-5PM)</label>
                    <input type="text" name="clinic_hours" value="<?php echo $edit_doc['clinic_hours'] ?? ''; ?>" required>
                </div>
                <div class="input-group">
                    <label>Video Hours (e.g. Mon-Sun: 6PM-10PM)</label>
                    <input type="text" name="video_hours" value="<?php echo $edit_doc['video_hours'] ?? ''; ?>" required>
                </div>

                <div class="input-group" style="display: flex; align-items: center; gap: 10px; margin-top: 2rem; grid-column: span 2;">
                    <input type="checkbox" name="video_consultation" id="video_consultation" <?php echo isset($edit_doc['video_consultation']) && $edit_doc['video_consultation'] ? 'checked' : ''; ?> style="width: auto;">
                    <label for="video_consultation" style="margin-bottom: 0;">Available for Video Consultation</label>
                </div>

                <div class="input-group" style="grid-column: span 2;"><label>Education (Comma separated)</label><input type="text" name="education" value="<?php echo $edit_doc['education'] ?? ''; ?>" required></div>
                <div class="input-group" style="grid-column: span 2;"><label>Clinic Address</label><textarea name="clinic_address" required><?php echo $edit_doc['clinic_address'] ?? ''; ?></textarea></div>
                <div class="input-group" style="grid-column: span 2;"><label>About (Bio)</label><textarea name="about" style="height:100px;" required><?php echo $edit_doc['about'] ?? ''; ?></textarea></div>
                
                <!-- Ranking & Status -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; background: #f8fafc; padding: 1.5rem; border-radius: 12px; border: 1px dashed #cbd5e1; margin-bottom: 2rem; grid-column: span 2;">
                    <div>
                        <label style="display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--primary);">Profile Ranking (Priority)</label>
                        <input type="number" name="ranking" value="<?php echo $edit_doc['ranking'] ?? 0; ?>" 
                               placeholder="e.g. 10 (Higher shows first)" 
                               style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid #ddd;">
                        <small style="color: #64748b;">Higher numbers appear first in lists.</small>
                    </div>
                    <div>
                        <label style="display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--primary);">Profile Status</label>
                        <select name="status" style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid #ddd; background: white;">
                            <option value="1" <?php echo (isset($edit_doc['status']) && $edit_doc['status'] == 1) ? 'selected' : ''; ?>>✅ Active (Visible)</option>
                            <option value="0" <?php echo (isset($edit_doc['status']) && $edit_doc['status'] == 0) ? 'selected' : ''; ?>>❌ Inactive (Hidden)</option>
                        </select>
                        <small style="color: #64748b;">Deactivate to hide from patients.</small>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; grid-column: span 2;">
                    <button type="submit" name="save_doctor" class="btn" style="flex: 1; padding: 1.2rem; font-size: 1.1rem;"><?php echo $edit_doc ? 'Update Doctor Profile' : 'Register New Doctor'; ?></button>
                    <?php if ($edit_doc): ?>
                        <a href="admin_doctors.php" class="btn" style="background: #f1f5f9; color: #475569; padding: 1.2rem; box-shadow: none;">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Doctor List Table -->
        <div class="table-card">
            <h3>Doctor Directory</h3>
            <table>
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Specialty</th>
                        <th>Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($doctors)): ?>
                        <tr><td colspan="5" style="text-align:center; padding:3rem;">No doctors found matching filters.</td></tr>
                    <?php
else: ?>
                        <?php foreach ($doctors as $doc): ?>
                        <tr>
                            <td><img src="assets/images/<?php echo $doc['profile_image']; ?>" style="width:40px; height:40px; border-radius:50%; object-fit:cover;" onerror="this.src='https://via.placeholder.com/40?text=DR';"></td>
                            <td style="font-weight:600;"><?php echo $doc['name']; ?></td>
                            <td><?php echo $doc['specialty']; ?></td>
                            <td><?php echo $doc['city']; ?></td>
                            <td>
                                <?php if ($_SESSION['role'] === 'Admin'): ?>
                                    <div style="display: flex; gap: 5px;">
                                        <a href="admin_doctors.php?edit=<?php echo $doc['id']; ?>" class="action-btn" style="background: #e0e7ff; color: #4338ca;">Edit</a>
                                        <a href="admin_locations.php?doctor_id=<?php echo $doc['id']; ?>" class="action-btn" style="background: #fef3c7; color: #92400e;">Locations</a>
                                        <a href="admin_doctors.php?delete=<?php echo $doc['id']; ?>" class="action-btn" style="background: #fee2e2; color: #dc2626;" onclick="return confirm('Are you sure?')">Delete</a>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php
    endforeach; ?>
                    <?php
endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
