-- Doctor Portfolio Platform Database Schema
CREATE DATABASE IF NOT EXISTS doctor_portfolio_db;
USE doctor_portfolio_db;

-- Table for doctor profiles
CREATE TABLE IF NOT EXISTS doctors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    specialty VARCHAR(100) NOT NULL,
    experience INT DEFAULT 0,
    city VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    profile_image VARCHAR(255) DEFAULT 'default-doctor.jpg',
    education TEXT,
    clinic_name VARCHAR(255),
    clinic_address TEXT,
    about TEXT,
    video_consultation TINYINT(1) DEFAULT 0,
    clinic_fee DECIMAL(10,2) DEFAULT 0.00,
    video_fee DECIMAL(10,2) DEFAULT 0.00,
    clinic_hours VARCHAR(255) DEFAULT 'Mon-Fri: 9AM - 5PM',
    video_hours VARCHAR(255) DEFAULT 'Mon-Fri: 6PM - 9PM',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for practice locations
CREATE TABLE IF NOT EXISTS doctor_locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT NOT NULL,
    location_name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    fee DECIMAL(10,2) DEFAULT 0.00,
    schedule VARCHAR(255) DEFAULT 'Mon-Fri: 9AM - 5PM',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for patient reviews
CREATE TABLE IF NOT EXISTS reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    doctor_id INT NOT NULL,
    patient_name VARCHAR(100) NOT NULL,
    comment TEXT NOT NULL,
    rating INT DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert some dummy data for testing
INSERT INTO doctors (name, experience, city, phone, profile_image, education, clinic_name, clinic_address, about) VALUES
('Dr. Muhammad Amjad', 28, 'Lahore', '+923001234567', 'doctor1.jpg', 'MBBS, MCPS (Dermatology), FCPS (Dermatology)', 'Skin & Laser Clinic', 'Block 4, Gulshan-e-Iqbal, Karachi', 'Specialist in skin disorders and cosmetic treatments with over 28 years of clinical experience.'),
('Dr. Aisha Ahmad', 12, 'Lahore', '+923219876543', 'doctor2.jpg', 'MBBS, FCPS (Dermatology), Certified (Aesthetic Medicine)', 'National Medical Center', 'Main Boulevard, Gulberg, Lahore', 'Dedicated dermatologist focused on aesthetic medicine and advanced diagnostics.'),
('Dr. Qurat Ul Ain Sajida', 18, 'Lahore', '+923335554444', 'doctor3.jpg', 'MBBS, MCPS (Dermatology)', 'Doctors Hospital', 'Sector F-8, Islamabad', 'Expert dermatologist providing comprehensive skin care.');

INSERT INTO reviews (doctor_id, patient_name, comment, rating) VALUES
(1, 'Ali Raza', 'Excellent experience, very professional.', 5),
(1, 'Hina Malik', 'Wait time was a bit long but the treatment was great.', 4),
(2, 'Zainab Bibi', 'Very knowledgeable and kind doctor.', 5),
(3, 'Usman Khan', 'Great with skin, highly recommended.', 5);
