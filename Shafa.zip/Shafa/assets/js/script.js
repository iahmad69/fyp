document.addEventListener('DOMContentLoaded', () => {
    console.log('Healthcare App Shafa Loaded');
});
