<?php
require_once 'db.php';
session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header("Location: admin_dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shafa Admin Login</title>
    <link rel="stylesheet" href="/Shafa/assets/css/style.css">
    <style>
        body { background: radial-gradient(at top left, #845EC2 0%, #fff 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { background: white; padding: 3rem; border-radius: 20px; box-shadow: var(--shadow-md); width: 100%; max-width: 400px; text-align: center; }
        .login-card h2 { margin-bottom: 2rem; color: var(--primary); font-size: 2rem; }
        .input-group { text-align: left; margin-bottom: 1.5rem; }
        .input-group label { display: block; margin-bottom: 0.5rem; font-size: 0.9rem; color: var(--text-secondary); }
        .input-group input { width: 100%; padding: 12px; border-radius: 10px; border: 1px solid var(--border-soft); font-family: inherit; }
        .error { color: #d63031; font-size: 0.85rem; margin-bottom: 1.5rem; }
    </style>
</head>
<body class="fade-in">
    <div class="login-card">
        <h2>Shafa Admin</h2>
        <?php if ($error): ?> <div class="error"><?php echo $error; ?></div> <?php endif; ?>
        <form method="POST">
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="Enter username" required autofocus>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn" style="width: 100%; padding: 15px;">Login to Dashboard</button>
        </form>
    </div>
</body>
</html>
