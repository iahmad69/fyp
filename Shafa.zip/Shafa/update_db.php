<?php
require_once 'db.php';

echo "<h2>Shafa Database Migration</h2>";

try {
    // Check and add video_consultation
    $checkVideo = $conn->query("SHOW COLUMNS FROM doctors LIKE 'video_consultation'")->fetch();
    if (!$checkVideo) {
        $conn->exec("ALTER TABLE doctors ADD COLUMN video_consultation TINYINT(1) DEFAULT 0");
        echo "<p style='color:green;'>✅ Column 'video_consultation' added.</p>";
    } else {
        echo "<p style='color:blue;'>ℹ️ Column 'video_consultation' already exists.</p>";
    }

    // Check and add consultation_fee
    $checkFee = $conn->query("SHOW COLUMNS FROM doctors LIKE 'consultation_fee'")->fetch();
    if (!$checkFee) {
        $conn->exec("ALTER TABLE doctors ADD COLUMN consultation_fee DECIMAL(10,2) DEFAULT 0.00");
        echo "<p style='color:green;'>✅ Column 'consultation_fee' added.</p>";
    } else {
        echo "<p style='color:blue;'>ℹ️ Column 'consultation_fee' already exists.</p>";
    }

    echo "<h3>Database updated successfully!</h3>";
    echo "<p><a href='admin_doctors.php'>Go to Admin Panel</a></p>";

} catch (PDOException $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
