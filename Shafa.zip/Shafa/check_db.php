<?php
require_once 'db.php';
try {
    echo "<h3>Database Statistics</h3>";

    $total = $conn->query("SELECT COUNT(*) FROM doctors")->fetchColumn();
    echo "Total Doctors: " . $total . "<br>";

    echo "<h4>Specialty Breakdown</h4>";
    $stmt = $conn->query("SELECT specialty, COUNT(*) as count FROM doctors GROUP BY specialty");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<ul>";
    foreach ($rows as $row) {
        echo "<li>" . (isset($row['specialty']) ? $row['specialty'] : 'NULL') . ": " . $row['count'] . "</li>";
    }
    echo "</ul>";


}
catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
