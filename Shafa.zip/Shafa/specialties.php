<?php include 'includes/header.php'; ?>

<div class="container">
    <div class="section-title">
        <h1>Medical Specialties</h1>
        <p>Expert healthcare services across 25 specialized medical fields.</p>
    </div>

    <div class="spec-grid" style="margin-bottom: 8rem;">
        <?php
$specialties = [
    ['name' => 'Neurologist', 'icon' => '🧠'],
    ['name' => 'Neurosurgeon', 'icon' => '🔪'],
    ['name' => 'Psychiatrist', 'icon' => '🗯️'],
    ['name' => 'Cardiologist', 'icon' => '❤️'],
    ['name' => 'Interventional Cardiologist', 'icon' => '🩺'],
    ['name' => 'Cardiac Surgeon', 'icon' => '💓'],
    ['name' => 'Orthopedics', 'icon' => '🦴'],
    ['name' => 'Physiotherapy & Rehabilitation', 'icon' => '🚶'],
    ['name' => 'Sports Medicine', 'icon' => '🏋️'],
    ['name' => 'Pediatrician', 'icon' => '👶'],
    ['name' => 'Neonatologist', 'icon' => '🍼'],
    ['name' => 'Gynecologist', 'icon' => '♀️'],
    ['name' => 'Obstetrics', 'icon' => '🤰'],
    ['name' => 'Infertility Specialist', 'icon' => '✨'],
    ['name' => 'Dermatologist', 'icon' => '🧴'],
    ['name' => 'Cosmetologist', 'icon' => '💅'],
    ['name' => 'Ophthalmologist', 'icon' => '👁️'],
    ['name' => 'ENT Specialist', 'icon' => '👂'],
    ['name' => 'Dentist', 'icon' => '🦷'],
    ['name' => 'Orthodontics', 'icon' => '😬'],
    ['name' => 'Pulmonologist', 'icon' => '🫁'],
    ['name' => 'Internal Medicine Specialist', 'icon' => '🏥'],
    ['name' => 'General Physician', 'icon' => '👨‍⚕️'],
    ['name' => 'Gastroenterologist', 'icon' => '🍎'],
    ['name' => 'Urologist', 'icon' => '🔬']
];

foreach ($specialties as $spec): ?>
            <a href="doctors.php?specialty=<?php echo urlencode($spec['name']); ?>" class="spec-item" style="text-decoration: none; color: inherit;">
                <span style="font-size: 3rem; display: block; margin-bottom: 1.2rem;"><?php echo $spec['icon']; ?></span>
                <h3 style="font-size: 1.1rem; font-weight: 600;"><?php echo $spec['name']; ?></h3>
                <p style="font-size: 0.85rem; font-weight: 300; margin-top: 0.6rem; opacity: 0.8;">Find specialists &rarr;</p>
            </a>
        <?php
endforeach; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
