<?php

$host = "127.0.0.1";
$dbname = "doctor_portfolio_db";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo = $conn; // Keep $pdo for compatibility if needed elsewhere
}
catch (PDOException $e) {
}
?>
