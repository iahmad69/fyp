<?php
require_once 'db.php';

echo "<h2>Adding New Doctors for Slider...</h2>";

$new_doctors = [
    [
        'name' => 'Dr. Sarah Hassan',
        'specialty' => 'Cardiologist',
        'experience' => 12,
        'city' => 'Lahore',
        'education' => 'MBBS, FCPS (Cardiology)',
        'clinic_name' => 'Heart Care Center',
        'clinic_address' => '78-B, Gulberg III, Lahore',
        'about' => 'Senior cardiologist with over 12 years of experience in managing complex heart conditions.',
        'phone' => '0300-1122334',
        'profile_image' => 'doctor_placeholder.jpg',
        'video_consultation' => 1,
        'clinic_fee' => 2500,
        'video_fee' => 2000,
        'clinic_hours' => 'Mon-Fri: 4PM - 8PM',
        'video_hours' => 'Sat-Sun: 10AM - 2PM'
    ],
    [
        'name' => 'Dr. Ali Raza',
        'specialty' => 'Orthopedic Surgeon',
        'experience' => 15,
        'city' => 'Karachi',
        'education' => 'MBBS, MS (Orthopedics)',
        'clinic_name' => 'Bone & Joint Clinic',
        'clinic_address' => 'Plot 45, DHA Phase 6, Karachi',
        'about' => 'Specialist in joint replacement and sports injuries.',
        'phone' => '0321-9988776',
        'profile_image' => 'doctor_placeholder.jpg',
        'video_consultation' => 0,
        'clinic_fee' => 3000,
        'video_fee' => 0,
        'clinic_hours' => 'Tue-Sat: 5PM - 9PM',
        'video_hours' => ''
    ],
    [
        'name' => 'Dr. Maria Khan',
        'specialty' => 'Gynecologist',
        'experience' => 8,
        'city' => 'Islamabad',
        'education' => 'MBBS, MRCOG',
        'clinic_name' => 'Motherhood Hospital',
        'clinic_address' => 'Sector F-8, Islamabad',
        'about' => 'Compassionate gynecologist focusing on maternal health and wellness.',
        'phone' => '0333-5566778',
        'profile_image' => 'doctor_placeholder.jpg',
        'video_consultation' => 1,
        'clinic_fee' => 2000,
        'video_fee' => 1500,
        'clinic_hours' => 'Mon-Thu: 10AM - 4PM',
        'video_hours' => 'Daily: 8PM - 10PM'
    ]
];

try {
    $stmt = $conn->prepare("INSERT INTO doctors (name, specialty, experience, city, education, clinic_name, clinic_address, about, phone, profile_image, video_consultation, clinic_fee, video_fee, clinic_hours, video_hours) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    foreach ($new_doctors as $doc) {
        $stmt->execute([
            $doc['name'], $doc['specialty'], $doc['experience'], $doc['city'], $doc['education'], 
            $doc['clinic_name'], $doc['clinic_address'], $doc['about'], $doc['phone'], 
            $doc['profile_image'], $doc['video_consultation'], $doc['clinic_fee'], 
            $doc['video_fee'], $doc['clinic_hours'], $doc['video_hours']
        ]);
        echo "<p style='color:green;'>✅ Added: " . $doc['name'] . "</p>";
    }

    echo "<h3>Success! 3 New Doctors Added.</h3>";
    echo "<p><a href='index.php'>Go to Home Page to see the Slider</a></p>";

} catch (PDOException $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>
