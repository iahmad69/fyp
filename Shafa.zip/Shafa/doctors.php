<?php
require_once 'db.php';
$pageTitle = "Find a Doctor";
include 'includes/header.php';

// Fetch doctors based on specialty and search filters
$specialty = isset($_GET['specialty']) ? $_GET['specialty'] : '';
$search = isset($_GET['q']) ? $_GET['q'] : '';

$sql = "SELECT * FROM doctors WHERE status = 1 ";
$params = [];

if ($specialty) {
    $sql .= "AND LOWER(TRIM(specialty)) = LOWER(TRIM(?)) ";
    $params[] = $specialty;
}

if ($search) {
    $sql .= "AND (name LIKE ? OR specialty LIKE ? OR city LIKE ?) ";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

$sql .= " ORDER BY ranking DESC, name ASC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$doctors = $stmt->fetchAll();
?>

<style>
    /* Premium Directory Hero */
    .directory-hero {
        padding: 8rem 0 6rem;
        background: radial-gradient(at top left, rgba(132, 94, 194, 0.2) 0%, #fff 70%),
                    radial-gradient(at bottom right, rgba(214, 93, 177, 0.15) 0%, #fff 70%);
        background-blend-mode: soft-light;
        border-radius: 0 0 60px 60px;
        text-align: center;
        margin-bottom: 4rem;
        position: relative;
        overflow: hidden;
    }
    .directory-hero::before {
        content: '';
        position: absolute;
        top: -10%;
        right: -5%;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(132, 94, 194, 0.05) 0%, transparent 70%);
        z-index: 0;
    }
    .directory-hero .container {
        position: relative;
        z-index: 1;
    }
    .directory-hero h1 {
        font-size: 3.5rem;
        font-weight: 800;
        letter-spacing: -2px;
        line-height: 1.1;
        color: #2D3436;
        margin-bottom: 1.5rem;
    }
    .directory-hero p {
        color: #64748b;
        font-size: 1.2rem;
        max-width: 650px;
        margin: 0 auto 3rem;
        line-height: 1.6;
    }

    /* Redesigned Search Bar */
    .search-container {
        max-width: 750px;
        margin: 0 auto;
        position: relative;
        padding: 0 1rem;
    }
    .search-form {
        display: flex;
        background: white;
        padding: 10px;
        border-radius: 100px;
        box-shadow: 0 20px 40px rgba(132, 94, 194, 0.15);
        border: 1px solid rgba(132, 94, 194, 0.1);
        transition: var(--transition);
    }
    .search-form:focus-within {
        box-shadow: 0 25px 50px rgba(132, 94, 194, 0.2);
        border-color: var(--primary);
        transform: translateY(-3px);
    }
    .search-input {
        flex: 1;
        padding: 1.2rem 2.5rem;
        border: none;
        outline: none;
        font-size: 1.1rem;
        background: transparent;
        color: #1e293b;
    }
    .search-btn {
        background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        color: white;
        border: none;
        padding: 0 3rem;
        border-radius: 100px;
        font-size: 1.1rem;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(132, 94, 194, 0.3);
    }
    .search-btn:hover {
        background: var(--primary-dark);
        transform: scale(1.03);
        box-shadow: 0 8px 25px rgba(132, 94, 194, 0.4);
    }

    /* Search Bar Mobile Stacking */
    @media (max-width: 540px) {
        .search-form {
            flex-direction: column !important;
            background: transparent !important;
            box-shadow: none !important;
            border: none !important;
            gap: 12px !important;
            padding: 0 !important;
        }
        .search-input {
            background: white !important;
            border-radius: 100px !important;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05) !important;
            width: 100% !important;
            padding: 1.2rem 2rem !important;
        }
        .search-btn {
            width: 100% !important;
            padding: 1.2rem !important;
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
        }
        .search-btn-text {
            display: inline-block !important;
        }
    }

    /* Enhanced Catalog Cards */
    .doctor-list {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        padding-bottom: 5rem;
    }
    .doctor-horizontal-card {
        background: white;
        border-radius: 24px;
        padding: 1.5rem;
        display: flex;
        gap: 2rem;
        border: 1px solid #f1f5f9;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.02);
        transition: var(--transition);
        position: relative;
        overflow: hidden;
    }
    .doctor-horizontal-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 30px -10px rgba(132, 94, 194, 0.12);
        border-color: rgba(132, 94, 194, 0.2);
    }
    .doctor-image-wrapper {
        flex-shrink: 0;
        position: relative;
    }
    .doctor-image-wrapper img {
        width: 140px;
        height: 140px;
        border-radius: 20px !important;
        object-fit: cover;
        border: 4px solid #f8fafc;
        box-shadow: var(--shadow-sm);
    }
    .verified-badge {
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        background: #2ecc71;
        color: white;
        font-size: 0.7rem;
        padding: 4px 10px;
        border-radius: 20px;
        font-weight: 700;
        white-space: nowrap;
        box-shadow: 0 4px 10px rgba(46, 204, 113, 0.3);
        border: 2px solid white;
    }
    .doctor-content {
        flex: 1;
    }
    .doctor-content h3 { margin: 0; }
    .doctor-content h3 a {
        color: #1e293b !important;
        text-decoration: none !important;
        font-size: 1.5rem;
        font-weight: 700;
        letter-spacing: -0.5px;
    }
    .doctor-sub {
        font-size: 1rem;
        color: #64748b;
        margin: 0.5rem 0 1.5rem;
        line-height: 1.4;
    }
    .specialty-tag {
        color: var(--primary);
        font-weight: 600;
        background: rgba(132, 94, 194, 0.08);
        padding: 2px 8px;
        border-radius: 6px;
    }
    .doctor-stats {
        display: flex;
        gap: 2.5rem;
        padding-top: 1.2rem;
        border-top: 1px solid #f1f5f9;
    }
    .stat-box {
        display: flex;
        flex-direction: column;
    }
    .stat-label {
        font-size: 0.75rem;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 2px;
    }
    .stat-value {
        font-size: 1.1rem;
        font-weight: 700;
        color: #1e293b;
    }
    .action-sidebar {
        display: flex;
        flex-direction: column;
        gap: 12px;
        padding-left: 2rem;
        border-left: 1px solid #f1f5f9;
        min-width: 210px;
        justify-content: center;
    }
    .btn-directory {
        text-align: center;
        padding: 14px;
        border-radius: 14px;
        text-decoration: none;
        font-weight: 700;
        font-size: 0.95rem;
        display: block;
        transition: var(--transition);
    }
    .btn-video-call {
        background: #2ecc71;
        color: white;
        box-shadow: 0 8px 15px rgba(46, 204, 113, 0.2);
    }
    .btn-video-call:hover { background: #27ae60; transform: translateY(-2px); }
    
    .btn-view-profile {
        background: #f1f5f9;
        color: #475569;
    }
    .btn-view-profile:hover { background: #e2e8f0; color: #1e293b; }

    @media (max-width: 992px) {
        .doctor-horizontal-card { gap: 1.5rem; }
        .action-sidebar { min-width: 180px; padding-left: 1.5rem; }
    }
</style>

<section class="directory-hero">
    <div class="container">
        <h1><?php echo $specialty ? "Specialists in " . htmlspecialchars($specialty) : "Medical Directory"; ?></h1>
        <p><?php echo $search ? "Showing results for '" . htmlspecialchars($search) . "'" : "Connect with Pakistan's top-rated doctors and healthcare specialists."; ?></p>
        
        <div class="search-container">
            <form action="doctors.php" method="GET" class="search-form">
                <?php if ($specialty): ?>
                    <input type="hidden" name="specialty" value="<?php echo htmlspecialchars($specialty); ?>">
                <?php endif; ?>
                <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" 
                       placeholder="Search name, specialty, or city..." class="search-input">
                <button type="submit" class="search-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="width: 18px; height: 18px; margin-right: 8px; vertical-align: middle;">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    <span class="search-btn-text">Search</span>
                </button>
            </form>
            <?php if ($search || $specialty): ?>
                <div style="margin-top: 1.5rem;">
                    <a href="doctors.php" style="color: var(--primary); font-weight: 600; font-size: 0.9rem; text-decoration: none;">&larr; Reset Filters</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<div class="container">
    <div class="doctor-list">
        <?php if (empty($doctors)): ?>
            <div style="text-align: center; padding: 5rem 0; background: white; border-radius: 30px; border: 1px dashed #cbd5e1;">
                <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
                <h2 style="color: #475569;">No Doctors Found</h2>
                <p style="color: #94a3b8; margin-bottom: 2rem;">We couldn't find any doctors matching your search criteria.</p>
                <a href="doctors.php" class="btn">View All Directory</a>
            </div>
        <?php else: ?>
            <?php foreach ($doctors as $doctor): ?>
                <div class="doctor-horizontal-card">
                    <div class="doctor-image-wrapper">
                        <img src="/Shafa/assets/images/<?php echo $doctor['profile_image']; ?>" alt="<?php echo $doctor['name']; ?>" onerror="this.src='https://via.placeholder.com/150x150?text=Doctor';">
                        <span class="verified-badge">✓ PMDC Verified</span>
                    </div>
                    
                    <div class="doctor-content">
                        <h3><a href="doctor.php?id=<?php echo $doctor['id']; ?>"><?php echo $doctor['name']; ?></a></h3>
                        <p class="doctor-sub">
                            <span class="specialty-tag"><?php echo htmlspecialchars($doctor['specialty']); ?></span> • 
                            <?php echo htmlspecialchars($doctor['education'] ?? 'MBBS, Specialization'); ?>
                        </p>

                        <div class="doctor-stats">
                            <div class="stat-box">
                                <span class="stat-label">Feedback</span>
                                <span class="stat-value">
                                    <?php 
                                        $revCountStmt = $conn->prepare("SELECT COUNT(*) FROM reviews WHERE doctor_id = ?");
                                        $revCountStmt->execute([$doctor['id']]);
                                        $totalRev = $revCountStmt->fetchColumn();
                                        echo number_format($totalRev);
                                    ?>
                                </span>
                            </div>
                            <div class="stat-box">
                                <span class="stat-label">Experience</span>
                                <span class="stat-value"><?php echo $doctor['experience']; ?> Yrs</span>
                            </div>
                            <?php if ($totalRev > 0): ?>
                            <div class="stat-box">
                                <span class="stat-label">Satisfaction</span>
                                <span class="stat-value">
                                    <?php 
                                        $avgStmt = $conn->prepare("SELECT AVG(rating) FROM reviews WHERE doctor_id = ?");
                                        $avgStmt->execute([$doctor['id']]);
                                        $avgR = $avgStmt->fetchColumn();
                                        echo round(($avgR / 5) * 100) . "%";
                                    ?>
                                </span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div style="margin-top: 1.5rem; display: flex; gap: 8px; flex-wrap: wrap;">
                            <span style="font-size: 0.85rem; color: #64748b; background: #f8fafc; padding: 4px 12px; border-radius: 50px; border: 1px solid #e2e8f0;">
                                📍 <?php echo htmlspecialchars($doctor['city']); ?>
                            </span>
                            <?php if (isset($doctor['video_consultation']) && $doctor['video_consultation']): ?>
                                <span style="font-size: 0.85rem; color: #059669; background: #ecfdf5; padding: 4px 12px; border-radius: 50px; border: 1px solid #d1fae5;">
                                    📹 Online Consultation
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="action-sidebar">
                        <a href="doctor.php?id=<?php echo $doctor['id']; ?>" class="btn-directory btn-view-profile">View Profile</a>
                        <?php if (isset($doctor['video_consultation']) && $doctor['video_consultation']): ?>
                            <a href="doctor.php?id=<?php echo $doctor['id']; ?>" class="btn-directory btn-video-call">Book Appointment</a>
                        <?php else: ?>
                            <a href="doctor.php?id=<?php echo $doctor['id']; ?>" class="btn-directory btn-video-call" style="background: var(--primary);">Book Clinic Visit</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
