    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <h4 class="logo" style="color:var(--primary); font-size: 1.5rem; margin-bottom: 1.5rem; display: block;">Shafa</h4>
                    <p style="color:var(--text-secondary); font-size: 0.95rem; font-weight: 300;">Providing premium healthcare search and connection services. Your health, our priority.</p>
                </div>
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="/Shafa/index.php">Home</a></li>
                        <li><a href="/Shafa/doctors.php">Browse Doctors</a></li>
                        <li><a href="/Shafa/about.php">About Us</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Specialties</h4>
                    <ul>
                        <li><a href="/Shafa/specialties.php">Dermatology</a></li>
                        <li><a href="/Shafa/specialties.php">Cardiology</a></li>
                        <li><a href="/Shafa/specialties.php">Orthopedics</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contact Us</h4>
                    <ul>
                        <li><a href="#">support@shafa.com</a></li>
                        <li><a href="#">+92 300 1234567</a></li>
                        <li><a href="#">Lahore, Pakistan</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 Shafa Healthcare Platform. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <script src="/Shafa/assets/js/script.js"></script>
</body>
</html>
