<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . " | Shafa" : "Shafa - Premium Healthcare Platform"; ?></title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🩺</text></svg>">
    <link rel="stylesheet" href="/Shafa/assets/css/style.css">
    <link rel="stylesheet" href="/Shafa/assets/css/home_enhancements.css">
    <link rel="stylesheet" href="/Shafa/assets/css/responsive.css">
</head>
<body class="fade-in">
    <header>
        <div class="container" style="display: flex; justify-content: space-between; align-items: center; position: relative;">
        <a href="index.php" class="logo">Shafa</a>
        
        <!-- Hamburger Menu -->
        <input type="checkbox" id="nav-toggle" class="nav-toggle" style="display: none;">
        <label for="nav-toggle" class="nav-toggle-label">
            <span></span>
        </label>

        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="doctors.php">Doctors</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </div>
    </header>
    <div> <!-- Container removed here to allow full-width Hero in index.php, will add back in pages -->
