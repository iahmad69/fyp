<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: admin_login.php");
    exit;
}

require_once 'db.php';

// Fetch stats
$doctorCount = $conn->query("SELECT COUNT(*) FROM doctors")->fetchColumn();
$reviewCount = $conn->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
$specCount = $conn->query("SELECT COUNT(DISTINCT specialty) FROM doctors")->fetchColumn();

// Fetch latest doctors
$latestDocs = $conn->query("SELECT * FROM doctors ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Shafa Admin</title>
    <link rel="stylesheet" href="/Shafa/assets/css/style.css">
    <style>
        body { display: flex; min-height: 100vh; background: #f0f2f5; }
        .admin-sidebar { width: 280px; background: white; border-right: 1px solid var(--border-soft); padding: 2rem; display: flex; flex-direction: column; }
        .admin-main { flex: 1; padding: 3rem; overflow-y: auto; }
        .nav-list { list-style: none; margin-top: 3rem; flex: 1; }
        .nav-list li { margin-bottom: 1rem; }
        .nav-list a { text-decoration: none; color: var(--text-secondary); display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; transition: var(--transition); }
        .nav-list a:hover, .nav-list a.active { background: var(--primary); color: white; }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; margin-bottom: 3rem; }
        .stat-card { background: white; padding: 2rem; border-radius: 20px; box-shadow: var(--shadow-sm); border: 1px solid var(--border-soft); }
        .stat-card h3 { font-size: 0.9rem; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 0.5rem; }
        .stat-card p { font-size: 2.5rem; font-weight: 700; color: var(--primary); }
        .table-card { background: white; border-radius: 20px; padding: 2rem; box-shadow: var(--shadow-sm); border: 1px solid var(--border-soft); }
        table { width: 100%; border-collapse: collapse; margin-top: 1.5rem; }
        th { text-align: left; padding: 15px; border-bottom: 1px solid var(--border-soft); color: var(--text-secondary); font-size: 0.9rem; }
        td { padding: 15px; border-bottom: 1px solid var(--border-soft); font-size: 0.95rem; }
    </style>
</head>
<body class="fade-in">
    <div class="admin-sidebar">
        <a href="index.php" class="logo" style="text-decoration:none; color:var(--primary); font-size: 2rem; font-weight:700;">Shafa</a>
        <ul class="nav-list">
            <li><a href="admin_dashboard.php" class="active"><span>📊</span> Dashboard</a></li>
            <li><a href="admin_doctors.php"><span>👨‍⚕️</span> Manage Doctors</a></li>
            <li><a href="admin_reviews.php"><span>⭐</span> Manage Reviews</a></li>
        </ul>
        <div style="border-top:1px solid #eee; padding-top:2rem;">
            <p style="font-size: 0.85rem; color:var(--text-secondary);">Logged in as:</p>
            <p style="font-weight:600;"><?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['role']; ?>)</p>
            <a href="logout.php" style="color:#d63031; text-decoration:none; font-size:0.9rem; display:block; margin-top:10px;">Logout</a>
        </div>
    </div>

    <main class="admin-main">
        <h1 style="margin-bottom: 2rem; font-size: 2.5rem; letter-spacing:-1px;">Dashboard Overview</h1>
        
        <div class="stat-grid">
            <div class="stat-card"><h3>Total Doctors</h3><p><?php echo $doctorCount; ?></p></div>
            <div class="stat-card"><h3>Total Reviews</h3><p><?php echo $reviewCount; ?></p></div>
            <div class="stat-card"><h3>Specialties</h3><p><?php echo $specCount; ?></p></div>
        </div>

        <div class="table-card">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h2>Recently Added Doctors</h2>
                <a href="admin_doctors.php" class="btn" style="font-size: 0.8rem; padding: 8px 15px;">View All</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Specialty</th>
                        <th>Location</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($latestDocs as $doc): ?>
                    <tr>
                        <td style="font-weight:600;"><?php echo $doc['name']; ?></td>
                        <td><?php echo $doc['specialty']; ?></td>
                        <td><?php echo $doc['city']; ?></td>
                        <td><span style="color:green; background:#e1f5fe; padding:4px 8px; border-radius:4px; font-size:0.75rem;">Active</span></td>
                    </tr>
                    <?php
endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
