<?php
require_once 'db.php';
$stmt = $conn->query("SELECT name, specialty FROM doctors");
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>";
print_r($doctors);
echo "</pre>";
?>
