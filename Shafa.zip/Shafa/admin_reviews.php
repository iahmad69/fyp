<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: admin_login.php");
    exit;
}

require_once 'db.php';

$message = '';

// Handle Delete (Admin Only)
if (isset($_GET['delete'])) {
    if ($_SESSION['role'] !== 'Admin') {
        $message = "Error: Only Admins can delete reviews.";
    }
    else {
        $id = (int)$_GET['delete'];
        $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ?");
        $stmt->execute([$id]);
        $message = "Review deleted successfully.";
    }
}

// Handle Add Review
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_review'])) {
    $doctor_id = (int)$_POST['doctor_id'];
    $patient_name = $_POST['patient_name'];
    $rating = (int)$_POST['rating'];
    $comment = $_POST['comment'];

    if ($doctor_id > 0 && $patient_name && $comment) {
        $stmt = $conn->prepare("INSERT INTO reviews (doctor_id, patient_name, comment, rating) VALUES (?, ?, ?, ?)");
        $stmt->execute([$doctor_id, $patient_name, $comment, $rating]);
        $message = "Review added successfully.";
    }
    else {
        $message = "Error: Please fill in all fields.";
    }
}

// Fetch Doctors for Dropdown
$doctors = $conn->query("SELECT id, name FROM doctors ORDER BY name ASC")->fetchAll();

// Fetch Reviews
$reviews = $conn->query("SELECT reviews.*, doctors.name as doctor_name 
                        FROM reviews 
                        JOIN doctors ON reviews.doctor_id = doctors.id 
                        ORDER BY reviews.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reviews - Shafa Admin</title>
    <link rel="stylesheet" href="/Shafa/assets/css/style.css">
    <style>
        body { display: flex; min-height: 100vh; background: #f0f2f5; }
        .admin-sidebar { width: 280px; background: white; border-right: 1px solid var(--border-soft); padding: 2rem; display: flex; flex-direction: column; }
        .admin-main { flex: 1; padding: 3rem; overflow-y: auto; }
        .nav-list { list-style: none; margin-top: 3rem; flex: 1; }
        .nav-list a { text-decoration: none; color: var(--text-secondary); display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; transition: var(--transition); }
        .nav-list a:hover, .nav-list a.active { background: var(--primary); color: white; }
        .form-card, .table-card { background: white; border-radius: 20px; padding: 2rem; box-shadow: var(--shadow-sm); border: 1px solid var(--border-soft); margin-bottom: 2rem; }
        .input-group { margin-bottom: 1.2rem; }
        .input-group label { display: block; margin-bottom: 0.5rem; font-size: 0.9rem; font-weight: 600; }
        .input-group select, .input-group input, .input-group textarea { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #ddd; font-family: inherit; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { text-align: left; padding: 15px; border-bottom: 1px solid #eee; font-size: 0.9rem; }
        .action-btn { padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 0.8rem; color: white; }
        .btn-delete { background: #d63031; }
    </style>
</head>
<body class="fade-in">
    <div class="admin-sidebar">
        <a href="index.php" class="logo" style="text-decoration:none; color:var(--primary); font-size: 2rem; font-weight:700;">Shafa</a>
        <ul class="nav-list">
            <li><a href="admin_dashboard.php"><span>📊</span> Dashboard</a></li>
            <li><a href="admin_doctors.php"><span>👨‍⚕️</span> Manage Doctors</a></li>
            <li><a href="admin_reviews.php" class="active"><span>⭐</span> Manage Reviews</a></li>
        </ul>
        <div style="border-top:1px solid #eee; padding-top:2rem;">
            <a href="logout.php" style="color:#d63031; text-decoration:none; font-size:0.9rem;">Logout</a>
        </div>
    </div>

    <main class="admin-main">
        <h1>Manage Reviews</h1>
        <?php if ($message): ?> 
            <div style="background:<?php echo str_contains($message, 'Error') ? '#f8d7da' : '#d4edda'; ?>; color:<?php echo str_contains($message, 'Error') ? '#721c24' : '#155724'; ?>; padding:15px; border-radius:8px; margin-bottom:20px;">
                <?php echo $message; ?>
            </div> 
        <?php
endif; ?>

        <!-- Add Review Form -->
        <div class="form-card">
            <h3>Add New Patient Review</h3>
            <form method="POST" style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:1.5rem; margin-top:1.5rem;">
                <div class="input-group">
                    <label>Select Doctor</label>
                    <select name="doctor_id" required>
                        <option value="">-- Choose Doctor --</option>
                        <?php foreach ($doctors as $doc): ?>
                            <option value="<?php echo $doc['id']; ?>"><?php echo $doc['name']; ?></option>
                        <?php
endforeach; ?>
                    </select>
                </div>
                <div class="input-group">
                    <label>Patient Name</label>
                    <input type="text" name="patient_name" placeholder="John Doe" required>
                </div>
                <div class="input-group">
                    <label>Rating</label>
                    <select name="rating" required>
                        <option value="5">5 Stars (Excellent)</option>
                        <option value="4">4 Stars (Good)</option>
                        <option value="3">3 Stars (Average)</option>
                        <option value="2">2 Stars (Fair)</option>
                        <option value="1">1 Star (Poor)</option>
                    </select>
                </div>
                <div class="input-group" style="grid-column: span 3;">
                    <label>Review Comment</label>
                    <textarea name="comment" placeholder="Write the patient's feedback here..." style="height:80px;" required></textarea>
                </div>
                <div style="grid-column: span 3;">
                    <button type="submit" name="add_review" class="btn">Add Review</button>
                </div>
            </form>
        </div>

        <!-- Reviews Table -->
        <div class="table-card">
            <h3>Patient Feedback Directory</h3>
            <table>
                <thead>
                    <tr>
                        <th>Doctor</th>
                        <th>Patient</th>
                        <th>Rating</th>
                        <th>Comment</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($reviews)): ?>
                        <tr><td colspan="6" style="text-align:center;">No reviews found.</td></tr>
                    <?php
else: ?>
                        <?php foreach ($reviews as $rev): ?>
                        <tr>
                            <td><strong><?php echo $rev['doctor_name']; ?></strong></td>
                            <td><?php echo $rev['patient_name']; ?></td>
                            <td><span style="color:#FFB800;">★</span> <?php echo $rev['rating']; ?></td>
                            <td style="max-width: 250px; font-style: italic;"><?php echo $rev['comment']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($rev['created_at'])); ?></td>
                            <td>
                                <?php if ($_SESSION['role'] === 'Admin'): ?>
                                    <a href="admin_reviews.php?delete=<?php echo $rev['id']; ?>" class="action-btn btn-delete" onclick="return confirm('Delete this review?')">Remove</a>
                                <?php
        else: ?>
                                    <span style="color:#ccc; font-size:0.8rem;">Restricted</span>
                                <?php
        endif; ?>
                            </td>
                        </tr>
                        <?php
    endforeach; ?>
                    <?php
endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
