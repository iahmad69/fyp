<?php
require_once 'db.php';
$pageTitle = "Home";
include 'includes/header.php';

// Fetch 6 featured doctors for the slider (Ordered by Ranking)
$stmt = $conn->query("SELECT * FROM doctors WHERE status = 1 ORDER BY ranking DESC, created_at DESC LIMIT 6");
$featuredDoctors = $stmt->fetchAll();
?>

<style>
    /* FORCED SLIDER FIX */
    .doctor-slider {
        display: flex !important;
        gap: 20px !important;
        padding: 20px 0 !important;
        align-items: stretch !important;
    }
    .doctor-card {
        background: white !important;
        border-radius: 20px !important;
        padding: 25px !important;
        text-align: center !important;
        border: 1px solid #f1f5f9 !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05) !important;
        min-width: 280px !important;
        max-width: 280px !important;
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
        transition: transform 0.3s ease !important;
    }
    .doctor-card img {
        width: 120px !important;
        height: 120px !important;
        border-radius: 50% !important;
        object-fit: cover !important;
        margin-bottom: 15px !important;
        border: 4px solid #f8fafc !important;
        display: block !important;
    }
    .doctor-card h3 {
        font-size: 1.1rem !important;
        margin-bottom: 10px !important;
        color: #1e293b !important;
    }
    .doctor-card .info {
        font-size: 0.85rem !important;
        color: #64748b !important;
        margin-bottom: 8px !important;
    }

    /* Hero Search Bar Styles */
    .hero-search-wrapper {
        max-width: 700px;
        margin: 3rem auto;
        position: relative;
    }
    .hero-search-form {
        display: flex;
        background: white;
        padding: 8px;
        border-radius: 60px;
        box-shadow: 0 15px 35px rgba(132, 94, 194, 0.15);
        border: 1px solid rgba(132, 94, 194, 0.1);
    }
    .hero-search-input {
        flex: 1;
        padding: 1.2rem 2rem;
        border: none;
        outline: none;
        font-size: 1.1rem;
        border-radius: 60px 0 0 60px;
        background: transparent;
        color: #1e293b;
    }
    .hero-search-btn {
        background: var(--primary);
        color: white;
        border: none;
        padding: 0 2.5rem;
        border-radius: 50px;
        font-size: 1.1rem;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(132, 94, 194, 0.3);
    }
    .hero-search-btn:hover {
        background: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(132, 94, 194, 0.4);
    }
</style>

<section class="hero">
    <div class="container">
        <h1>Your Health<br><span style="color:var(--primary);">Simplified.</span></h1>
        <p>Expert healthcare is just a click away. Connect with the best doctors and specialized clinics today.</p>
        
        <div class="hero-search-wrapper fade-in">
            <form action="doctors.php" method="GET" class="hero-search-form">
                <input type="text" name="q" placeholder="Search by name, specialty, or city..." class="hero-search-input">
                <button type="submit" class="hero-search-btn">Find Doctor</button>
            </form>
        </div>
    </div>
</section>

<!-- Specialties Section -->
<div class="container" style="margin-top: 4rem;">
    <div class="section-title">
        <h2>Find by Specialty</h2>
        <p>Choose from our wide range of specialized medical fields.</p>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 1.5rem; margin-top: 3rem;">
        <?php
        $specs = [
            ['name' => 'Cardiologist', 'icon' => '❤️'],
            ['name' => 'Dermatologist', 'icon' => '✨'],
            ['name' => 'Gynecologist', 'icon' => '👶'],
            ['name' => 'Pediatrics', 'icon' => '🧸'],
            ['name' => 'Orthopedic', 'icon' => '🦴'],
            ['name' => 'Neurologist', 'icon' => '🧠']
        ];
        foreach ($specs as $s):
        ?>
        <a href="doctors.php?specialty=<?php echo urlencode($s['name']); ?>" class="specialty-card">
            <div style="font-size: 2.5rem; margin-bottom: 1rem;"><?php echo $s['icon']; ?></div>
            <h4 style="color: #1e293b; font-weight: 600;"><?php echo $s['name']; ?></h4>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="container" style="margin-top: 4rem;">
    <div class="section-title">
        <h2>Featured Specialists</h2>
        <p>Connecting you with top-rated medical experts.</p>
    </div>

    <div class="slider-container">
        <div class="slider-btn prev" onclick="moveSlider(-1)">❮</div>
        <div class="slider-btn next" onclick="moveSlider(1)">❯</div>
        
        <div class="doctor-slider" id="doctorSlider">
            <?php foreach ($featuredDoctors as $doctor): ?>
                <div class="doctor-card" style="min-width: 280px;">
                    <img src="/Shafa/assets/images/<?php echo $doctor['profile_image']; ?>" alt="<?php echo $doctor['name']; ?>" onerror="this.src='https://via.placeholder.com/120x120?text=Doctor';">
                    <h3><?php echo $doctor['name']; ?></h3>
                        <?php 
                            $countStmt = $conn->prepare("SELECT COUNT(*), AVG(rating) FROM reviews WHERE doctor_id = ?");
                            $countStmt->execute([$doctor['id']]);
                            $res = $countStmt->fetch();
                            $totalR = $res[0];
                            $avgRating = $res[1];
                        ?>
                        <?php if ($totalR > 0): ?>
                        <div class="info">
                            <span style="color: #f39c12;">★</span> <?php echo round(($avgRating / 5) * 100); ?>% Satisfaction (<?php echo $totalR; ?> Reviews)
                        </div>
                        <?php endif; ?>
                    <p class="info"><?php echo $doctor['experience']; ?> Years Exp | <?php echo $doctor['city']; ?></p>
                    <a href="doctor.php?id=<?php echo $doctor['id']; ?>" class="btn">View Profile</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div style="text-align: center; margin-top: 2rem; margin-bottom: 4rem;">
        <a href="doctors.php" style="color: var(--primary); font-weight: 600; text-decoration: none; font-size: 1.1rem;">See Full Directory &rarr;</a>
    </div>
</div>

<section class="reviews-section">
    <div class="container">
        <div class="section-title">
            <h2>Patient Testimonials</h2>
            <p>Read what our community has to say about their experience.</p>
        </div>
        
        <div class="reviews-grid">
            <div class="review-card">
                <p class="review-text">"The experience was amazing. I booked a video consultation and the doctor was extremely professional and helpful."</p>
                <div class="reviewer-info">
                    <div class="reviewer-avatar" style="background: #e0e7ff;"></div>
                    <div>
                        <div class="reviewer-name">Sarah Ahmed</div>
                        <div class="reviewer-stars">★★★★★</div>
                    </div>
                </div>
            </div>
            <div class="review-card">
                <p class="review-text">"Very easy to find specialists. The clinic hours and fees were clearly mentioned, which helped me make an informed decision."</p>
                <div class="reviewer-info">
                    <div class="reviewer-avatar" style="background: #fef3c7;"></div>
                    <div>
                        <div class="reviewer-name">Mohammad Bilal</div>
                        <div class="reviewer-stars">★★★★★</div>
                    </div>
                </div>
            </div>
            <div class="review-card">
                <p class="review-text">"I highly recommend Shafa for anyone looking for reliable healthcare services in the city. Excellent platform!"</p>
                <div class="reviewer-info">
                    <div class="reviewer-avatar" style="background: #dcfce7;"></div>
                    <div>
                        <div class="reviewer-name">Zainab Khan</div>
                        <div class="reviewer-stars">★★★★★</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
let currentPos = 0;
const slider = document.getElementById('doctorSlider');

function moveSlider(direction) {
    const card = slider.children[0];
    const cardWidth = card.offsetWidth + parseInt(getComputedStyle(slider).gap);
    const visibleCards = Math.floor(slider.parentElement.clientWidth / (cardWidth - 10)); // Tolerance for gap
    const totalCards = slider.children.length;
    
    currentPos += direction;
    
    if (currentPos < 0) currentPos = 0;
    if (currentPos > totalCards - visibleCards) currentPos = totalCards - visibleCards;
    
    slider.style.transform = `translateX(-${currentPos * cardWidth}px)`;
}
</script>

<?php include 'includes/footer.php'; ?>
