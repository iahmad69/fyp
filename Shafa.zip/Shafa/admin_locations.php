<?php
require_once 'db.php';

// --- SELF REPAIR BLOCK ---
try {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'doctor_locations'")->fetch();
    if (!$tableCheck) {
        $conn->exec("CREATE TABLE IF NOT EXISTS doctor_locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            doctor_id INT NOT NULL,
            location_name VARCHAR(255) NOT NULL,
            address TEXT NOT NULL,
            fee DECIMAL(10,2) DEFAULT 0.00,
            schedule VARCHAR(255) DEFAULT 'Mon-Fri: 9AM - 5PM',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
        )");
    }
} catch (Exception $e) {}
// -------------------------

include 'includes/header.php';

$doctor_id = isset($_GET['doctor_id']) ? (int)$_GET['doctor_id'] : 0;

if (!$doctor_id) {
    header("Location: admin_doctors.php");
    exit();
}

// Fetch doctor info
$stmt = $conn->prepare("SELECT name FROM doctors WHERE id = ?");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch();

if (!$doctor) {
    die("Doctor not found.");
}

$message = '';

// Handle Add/Update Location
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $name = $_POST['location_name'];
            $address = $_POST['address'];
            $fee = $_POST['fee'];
            $schedule = $_POST['schedule'];
            
            $stmt = $conn->prepare("INSERT INTO doctor_locations (doctor_id, location_name, address, fee, schedule) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$doctor_id, $name, $address, $fee, $schedule]);
            $message = "Location added successfully!";
        } 
        elseif ($_POST['action'] == 'delete') {
            $id = $_POST['location_id'];
            $stmt = $conn->prepare("DELETE FROM doctor_locations WHERE id = ? AND doctor_id = ?");
            $stmt->execute([$id, $doctor_id]);
            $message = "Location removed successfully!";
        }
    }
}

// Fetch existing locations
$stmt = $conn->prepare("SELECT * FROM doctor_locations WHERE doctor_id = ? ORDER BY id ASC");
$stmt->execute([$doctor_id]);
$locations = $stmt->fetchAll();
?>

<div class="container" style="margin-top: 3rem; margin-bottom: 5rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <div>
            <h1 style="font-size: 2.5rem;">Manage Locations</h1>
            <p style="color: var(--text-secondary);">Adding multiple practice locations for <strong><?php echo $doctor['name']; ?></strong></p>
        </div>
        <a href="admin_doctors.php" class="btn" style="background: #f1f5f9; color: #475569; box-shadow: none;">&larr; Back to Doctors</a>
    </div>

    <?php if ($message): ?>
        <div style="background: #ecfdf5; color: #059669; padding: 1rem; border-radius: 12px; margin-bottom: 2rem; border: 1px solid #d1fae5;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 3rem; align-items: flex-start;">
        <!-- Add Location Form -->
        <div style="background: white; padding: 2rem; border-radius: 20px; box-shadow: var(--shadow-md); border: 1px solid var(--border-soft);">
            <h3 style="margin-bottom: 1.5rem;">Add New Location</h3>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div style="margin-bottom: 1.2rem;">
                    <label style="display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem;">Clinic/Hospital Name</label>
                    <input type="text" name="location_name" required placeholder="e.g. City Hospital" style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid #ddd;">
                </div>
                
                <div style="margin-bottom: 1.2rem;">
                    <label style="display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem;">Address</label>
                    <textarea name="address" required placeholder="Full physical address" style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid #ddd; height: 80px;"></textarea>
                </div>
                
                <div style="margin-bottom: 1.2rem;">
                    <label style="display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem;">Consultation Fee (Rs.)</label>
                    <input type="number" name="fee" required placeholder="e.g. 1500" style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid #ddd;">
                </div>
                
                <div style="margin-bottom: 2rem;">
                    <label style="display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem;">Timing Schedule</label>
                    <input type="text" name="schedule" required placeholder="e.g. Mon-Wed: 5PM-8PM" style="width: 100%; padding: 0.8rem; border-radius: 8px; border: 1px solid #ddd;">
                </div>
                
                <button type="submit" class="btn" style="width: 100%;">Save Location</button>
            </form>
        </div>

        <!-- Existing Locations List -->
        <div>
            <h3 style="margin-bottom: 1.5rem;">Existing Locations (<?php echo count($locations); ?>)</h3>
            <?php if (empty($locations)): ?>
                <div style="background: #f8fafc; padding: 3rem; text-align: center; border-radius: 20px; border: 1px dashed #cbd5e1;">
                    <p style="color: #64748b;">No locations added yet.</p>
                </div>
            <?php else: ?>
                <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                    <?php foreach ($locations as $loc): ?>
                        <div style="background: white; padding: 1.5rem; border-radius: 16px; border: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: flex-start;">
                            <div>
                                <h4 style="font-size: 1.2rem; margin-bottom: 0.5rem; color: var(--primary);"><?php echo htmlspecialchars($loc['location_name']); ?></h4>
                                <p style="font-size: 0.9rem; color: #5a5a5a; margin-bottom: 0.8rem;">📍 <?php echo htmlspecialchars($loc['address']); ?></p>
                                <div style="display: flex; gap: 20px; font-size: 0.85rem; font-weight: 600;">
                                    <span style="color: #059669;">💵 Fee: Rs. <?php echo number_format($loc['fee'], 0); ?></span>
                                    <span style="color: #6366f1;">🕒 Timing: <?php echo htmlspecialchars($loc['schedule']); ?></span>
                                </div>
                            </div>
                            <form method="POST" onsubmit="return confirm('Remove this location?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="location_id" value="<?php echo $loc['id']; ?>">
                                <button type="submit" style="background: #fee2e2; color: #dc2626; border: none; padding: 8px 12px; border-radius: 8px; cursor: pointer; font-size: 0.8rem; font-weight: 600;">Remove</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
