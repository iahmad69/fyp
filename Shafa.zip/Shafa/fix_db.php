<?php
require_once 'db.php';

echo "<h2>Shafa Database Force Repair</h2>";

try {
    // Check if the table exists
    $tableCheck = $conn->query("SHOW TABLES LIKE 'doctors'")->fetch();
    
    if (!$tableCheck) {
        echo "<p style='color:red;'>❌ Table 'doctors' does not exist! Please run schema.sql first.</p>";
    } else {
        echo "<p style='color:blue;'>🔍 Table 'doctors' found. Checking columns...</p>";
        
        $columns_to_add = [
            'specialty' => "VARCHAR(100) NOT NULL AFTER name",
            'video_consultation' => "TINYINT(1) DEFAULT 0 AFTER about",
            'consultation_fee' => "DECIMAL(10,2) DEFAULT 0.00 AFTER video_consultation"
        ];

        foreach ($columns_to_add as $col => $definition) {
            $check = $conn->query("SHOW COLUMNS FROM doctors LIKE '$col'")->fetch();
            if (!$check) {
                $conn->exec("ALTER TABLE doctors ADD COLUMN $col $definition");
                echo "<p style='color:green;'>✅ Successfully added column: <strong>$col</strong></p>";
            } else {
                echo "<p style='color:blue;'>ℹ️ Column <strong>$col</strong> already exists.</p>";
            }
        }
    }

    echo "<h3>System Repair Complete!</h3>";
    echo "<p><a href='admin_doctors.php'>Click here to go back to Admin Panel</a></p>";

} catch (PDOException $e) {
    echo "<p style='color:red;'>❌ CRITICAL ERROR: " . $e->getMessage() . "</p>";
}
?>
