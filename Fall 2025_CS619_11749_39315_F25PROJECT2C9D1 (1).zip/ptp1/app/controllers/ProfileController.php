<?php
class ProfileController extends Controller
{
    public function __construct()
    {
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/ptp1/public/auth/login');
        }
    }

    public function index()
    {
        $userModel = $this->model('UserModel');
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'id' => $_SESSION['user_id'],
                'name' => $_POST['name'],
                'email' => $_POST['email']
            ];
            // Simple update (ignoring password change for now to keep it brief)
            $db = (new Database())->getConnection();
            $stmt = $db->prepare("UPDATE users SET name = :name, email = :email WHERE id = :id");
            if ($stmt->execute($data)) {
                $_SESSION['user_name'] = $data['name'];
                $_SESSION['user_email'] = $data['email'];
                $data['success'] = "Profile updated successfully.";
            }
        }

        $db = (new Database())->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute(['id' => $_SESSION['user_id']]);
        $user = $stmt->fetch();

        // Ensure session has email if it was missing
        if (!isset($_SESSION['user_email'])) {
            $_SESSION['user_email'] = $user['email'];
        }

        $data['user'] = $user;
        $data['title'] = 'My Profile';

        $this->view('profile/index', $data);
    }
}
