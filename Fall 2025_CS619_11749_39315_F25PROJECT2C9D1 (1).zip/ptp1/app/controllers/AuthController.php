<?php
class AuthController extends Controller
{
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];

            $userModel = $this->model('UserModel');
            $user = $userModel->login($email, $password);

            if ($user && !isset($user['error'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role_name'];

                // Redirect based on role
                if ($user['role_name'] == 'Admin')
                    $this->redirect('/ptp1/public/admin/dashboard');
                elseif ($user['role_name'] == 'Instructor')
                    $this->redirect('/ptp1/public/instructor/dashboard');
                else
                    $this->redirect('/ptp1/public/student/dashboard');
            }
            else {
                $data['error'] = isset($user['error']) ? $user['error'] : "Invalid credentials.";
                $this->view('auth/login', $data);
            }
        }
        else {
            $this->view('auth/login');
        }
    }

    public function register()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'role_id' => $_POST['role_id']
            ];

            $userModel = $this->model('UserModel');
            if ($userModel->findByEmail($data['email'])) {
                $data['error'] = "Email already exists.";
                $this->view('auth/register', $data);
            }
            else {
                if ($userModel->register($data)) {
                    $this->redirect('/ptp1/public/auth/login?registered=1');
                }
                else {
                    $data['error'] = "Registration failed.";
                    $this->view('auth/register', $data);
                }
            }
        }
        else {
            $this->view('auth/register');
        }
    }

    public function logout()
    {
        session_destroy();
        $this->redirect('/ptp1/public/auth/login');
    }
}
