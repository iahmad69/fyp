<?php
class AdminController extends Controller
{
    public function __construct()
    {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'Admin') {
            $this->redirect('/ptp1/public/auth/login');
        }
    }

    public function dashboard()
    {
        $db = (new Database())->getConnection();

        // System Stats
        $data['stats']['total_users'] = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $data['stats']['total_instructors'] = $db->query("SELECT COUNT(*) FROM users WHERE role_id = 2")->fetchColumn();
        $data['stats']['total_students'] = $db->query("SELECT COUNT(*) FROM users WHERE role_id = 3")->fetchColumn();
        $data['stats']['total_courses'] = $db->query("SELECT COUNT(*) FROM courses")->fetchColumn();
        $data['stats']['pending_instructors'] = $db->query("SELECT COUNT(*) FROM users WHERE role_id = 2 AND is_approved = 0")->fetchColumn();

        $data['title'] = 'Admin Dashboard';
        $this->view('admin/dashboard', $data);
    }

    public function users()
    {
        $db = (new Database())->getConnection();
        $stmt = $db->query("SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id");
        $data['users'] = $stmt->fetchAll();
        $data['title'] = 'User Management';
        $this->view('admin/users', $data);
    }

    public function approve($id)
    {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("UPDATE users SET is_approved = 1 WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $this->redirect('/ptp1/public/admin/users');
    }

    public function block($id)
    {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("UPDATE users SET is_blocked = 1 WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $this->redirect('/ptp1/public/admin/users');
    }

    public function unblock($id)
    {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("UPDATE users SET is_blocked = 0 WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $this->redirect('/ptp1/public/admin/users');
    }

    public function add_user()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'password' => $_POST['password'],
                'role_id' => $_POST['role_id']
            ];

            $userModel = $this->model('UserModel');
            if ($userModel->findByEmail($data['email'])) {
                $data['error'] = "Email already exists.";
                $this->view('admin/add_user', $data);
            }
            else {
                if ($userModel->register($data)) {
                    // Auto approve if added by admin
                    $db = (new Database())->getConnection();
                    $db->prepare("UPDATE users SET is_approved = 1 WHERE email = ?")->execute([$data['email']]);

                    $this->redirect('/ptp1/public/admin/users?success=User added successfully');
                }
                else {
                    $data['error'] = "Failed to add user.";
                    $this->view('admin/add_user', $data);
                }
            }
        }
        else {
            $this->view('admin/add_user');
        }
    }
}
