<?php
class HomeController extends Controller
{
    public function index()
    {
        $data['title'] = "E-Learning Platform - CS619";
        $this->view('home/index', $data);
    }
}
