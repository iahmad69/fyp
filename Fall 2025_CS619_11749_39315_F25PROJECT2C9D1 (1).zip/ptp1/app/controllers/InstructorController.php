<?php
class InstructorController extends Controller
{
    public function __construct()
    {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'Instructor') {
            $this->redirect('/ptp1/public/auth/login');
        }
    }

    public function dashboard()
    {
        $courseModel = $this->model('CourseModel');
        $data['courses'] = $courseModel->getByInstructor($_SESSION['user_id']);
        $data['title'] = 'Instructor Dashboard';
        $this->view('instructor/dashboard', $data);
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'category' => $_POST['category'],
                'difficulty' => $_POST['difficulty'],
                'instructor_id' => $_SESSION['user_id']
            ];
            $courseModel = $this->model('CourseModel');
            if ($courseModel->create($data)) {
                $this->redirect('/ptp1/public/instructor/dashboard');
            }
        }
        $data['title'] = 'Create New Course';
        $this->view('instructor/create_course', $data);
    }

    public function edit($id)
    {
        $courseModel = $this->model('CourseModel');
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'category' => $_POST['category'],
                'difficulty' => $_POST['difficulty']
            ];
            if ($courseModel->update($id, $data)) {
                $this->redirect('/ptp1/public/instructor/dashboard');
            }
        }
        $data['course'] = $courseModel->getById($id);
        $this->view('instructor/edit_course', $data);
    }

    public function delete($id)
    {
        $courseModel = $this->model('CourseModel');
        $courseModel->delete($id);
        $this->redirect('/ptp1/public/instructor/dashboard');
    }

    public function lectures($course_id)
    {
        $lectureModel = $this->model('LectureModel');
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_lecture'])) {
            $data = [
                'course_id' => $course_id,
                'title' => $_POST['title'],
                'video_url' => $_POST['video_url'],
                'order_num' => $_POST['order_num']
            ];
            $lectureModel->create($data);
        }
        $data['course_id'] = $course_id;
        $data['lectures'] = $lectureModel->getByCourse($course_id);
        $data['title'] = 'Manage Lectures';
        $this->view('instructor/manage_lectures', $data);
    }

    public function materials($course_id)
    {
        $materialModel = $this->model('MaterialModel');
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_material'])) {
            $data = [
                'course_id' => $course_id,
                'title' => $_POST['title'],
                'file_path' => $_POST['file_path'] // Simple path for prototype
            ];
            $materialModel->create($data);
        }
        $data['course_id'] = $course_id;
        $data['materials'] = $materialModel->getByCourse($course_id);
        $data['title'] = 'Manage Materials';
        $this->view('instructor/manage_materials', $data);
    }
}
