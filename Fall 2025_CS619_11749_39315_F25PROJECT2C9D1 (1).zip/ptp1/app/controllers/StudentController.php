<?php
class StudentController extends Controller
{
    public function __construct()
    {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'Student') {
            $this->redirect('/ptp1/public/auth/login');
        }
    }

    public function dashboard()
    {
        $enrollmentModel = $this->model('EnrollmentModel');
        $progressModel = $this->model('ProgressModel');

        $enrolled = $enrollmentModel->getEnrolledCourses($_SESSION['user_id']);

        foreach ($enrolled as &$course) {
            $course['progress'] = $progressModel->getProgress($course['enrollment_id'], $course['id']);
        }

        $data['title'] = 'My Dashboard';
        $data['enrolled_courses'] = $enrolled;
        $this->view('student/dashboard', $data);
    }

    public function browse()
    {
        $courseModel = $this->model('CourseModel');
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $data['title'] = 'Browse Courses';
        $data['courses'] = $courseModel->getAll($search);
        $data['search'] = $search;
        $this->view('student/browse', $data);
    }

    public function course($id)
    {
        $courseModel = $this->model('CourseModel');
        $lectureModel = $this->model('LectureModel');
        $materialModel = $this->model('MaterialModel');
        $enrollmentModel = $this->model('EnrollmentModel');

        $data['course'] = $courseModel->getById($id);
        $data['title'] = $data['course']['title'];
        $data['lectures'] = $lectureModel->getByCourse($id);
        $data['materials'] = $materialModel->getByCourse($id);
        $data['is_enrolled'] = $enrollmentModel->isEnrolled($_SESSION['user_id'], $id);

        $this->view('student/course_view', $data);
    }

    public function enroll($id)
    {
        $enrollmentModel = $this->model('EnrollmentModel');
        if ($enrollmentModel->enroll($_SESSION['user_id'], $id)) {
            $this->redirect('/ptp1/public/student/dashboard');
        }
        else {
            $this->redirect('/ptp1/public/student/course/' . $id . '?error=1');
        }
    }

    public function play($lecture_id)
    {
        // Find enrollment and play lecture
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("SELECT l.*, c.id as course_id FROM lectures l JOIN courses c ON l.course_id = c.id WHERE l.id = :id");
        $stmt->execute(['id' => $lecture_id]);
        $lecture = $stmt->fetch();

        $enrollmentModel = $this->model('EnrollmentModel');
        $enrollment = $enrollmentModel->isEnrolled($_SESSION['user_id'], $lecture['course_id']);

        if (!$enrollment) {
            $this->redirect('/ptp1/public/student/browse');
        }

        $progressModel = $this->model('ProgressModel');
        $progressModel->markAsCompleted($enrollment['id'], $lecture_id);

        $data['lecture'] = $lecture;
        $data['enrollment_id'] = $enrollment['id'];

        // Fetch course and all lectures for the playlist
        $courseModel = $this->model('CourseModel');
        $lectureModel = $this->model('LectureModel');
        $data['course'] = $courseModel->getById($lecture['course_id']);
        $data['all_lectures'] = $lectureModel->getByCourse($lecture['course_id']);

        $this->view('student/player', $data);
    }
}
