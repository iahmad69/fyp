<?php
class ProgressModel extends Model
{
    public function markAsCompleted($enrollment_id, $lecture_id)
    {
        $sql = "INSERT IGNORE INTO progress (enrollment_id, lecture_id) VALUES (:enrollment_id, :lecture_id)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['enrollment_id' => $enrollment_id, 'lecture_id' => $lecture_id]);
    }

    public function getProgress($enrollment_id, $course_id)
    {
        // Count total lectures for the course
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM lectures WHERE course_id = :course_id");
        $stmt->execute(['course_id' => $course_id]);
        $total = $stmt->fetch()['total'];

        if ($total == 0)
            return 0;

        // Count completed lectures for this enrollment
        $stmt = $this->db->prepare("SELECT COUNT(*) as completed FROM progress WHERE enrollment_id = :enrollment_id");
        $stmt->execute(['enrollment_id' => $enrollment_id]);
        $completed = $stmt->fetch()['completed'];

        return round(($completed / $total) * 100);
    }

    public function getCompletedLectures($enrollment_id)
    {
        $stmt = $this->db->prepare("SELECT lecture_id FROM progress WHERE enrollment_id = :enrollment_id");
        $stmt->execute(['enrollment_id' => $enrollment_id]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}
