<?php
class CourseModel extends Model
{
    public function getAll($search = '')
    {
        $sql = "SELECT c.*, u.name as instructor_name FROM courses c JOIN users u ON c.instructor_id = u.id";
        if ($search) {
            $sql .= " WHERE c.title LIKE :search OR c.category LIKE :search OR u.name LIKE :search";
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['search' => "%$search%"]);
        }
        else {
            $stmt = $this->db->query($sql);
        }
        return $stmt->fetchAll();
    }

    public function getById($id)
    {
        $stmt = $this->db->prepare("SELECT c.*, u.name as instructor_name FROM courses c JOIN users u ON c.instructor_id = u.id WHERE c.id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function getByInstructor($instructor_id)
    {
        $stmt = $this->db->prepare("SELECT * FROM courses WHERE instructor_id = :instructor_id");
        $stmt->execute(['instructor_id' => $instructor_id]);
        return $stmt->fetchAll();
    }

    public function create($data)
    {
        $sql = "INSERT INTO courses (title, description, category, difficulty, instructor_id) VALUES (:title, :description, :category, :difficulty, :instructor_id)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function update($id, $data)
    {
        $sql = "UPDATE courses SET title = :title, description = :description, category = :category, difficulty = :difficulty WHERE id = :id";
        $data['id'] = $id;
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM courses WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
