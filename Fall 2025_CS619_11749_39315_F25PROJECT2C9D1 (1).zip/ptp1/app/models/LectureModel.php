<?php
class LectureModel extends Model
{
    public function getByCourse($course_id)
    {
        $stmt = $this->db->prepare("SELECT * FROM lectures WHERE course_id = :course_id ORDER BY order_num ASC");
        $stmt->execute(['course_id' => $course_id]);
        return $stmt->fetchAll();
    }

    public function create($data)
    {
        $sql = "INSERT INTO lectures (course_id, title, video_url, order_num) VALUES (:course_id, :title, :video_url, :order_num)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM lectures WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
