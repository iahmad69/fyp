<?php
class MaterialModel extends Model
{
    public function getByCourse($course_id)
    {
        $stmt = $this->db->prepare("SELECT * FROM materials WHERE course_id = :course_id");
        $stmt->execute(['course_id' => $course_id]);
        return $stmt->fetchAll();
    }

    public function create($data)
    {
        $sql = "INSERT INTO materials (course_id, title, file_path) VALUES (:course_id, :title, :file_path)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM materials WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
