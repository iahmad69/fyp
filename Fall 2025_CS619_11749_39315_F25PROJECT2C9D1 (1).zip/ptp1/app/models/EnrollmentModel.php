<?php
class EnrollmentModel extends Model
{
    public function enroll($student_id, $course_id)
    {
        $sql = "INSERT IGNORE INTO enrollments (student_id, course_id) VALUES (:student_id, :course_id)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['student_id' => $student_id, 'course_id' => $course_id]);
    }

    public function getEnrolledCourses($student_id)
    {
        $sql = "SELECT c.*, u.name as instructor_name, e.id as enrollment_id FROM enrollments e JOIN courses c ON e.course_id = c.id JOIN users u ON c.instructor_id = u.id WHERE e.student_id = :student_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['student_id' => $student_id]);
        return $stmt->fetchAll();
    }

    public function isEnrolled($student_id, $course_id)
    {
        $stmt = $this->db->prepare("SELECT id FROM enrollments WHERE student_id = :student_id AND course_id = :course_id");
        $stmt->execute(['student_id' => $student_id, 'course_id' => $course_id]);
        return $stmt->fetch();
    }
}
