<?php
class UserModel extends Model
{
    public function register($data)
    {
        $sql = "INSERT INTO users (name, email, password, role_id, is_approved) VALUES (:name, :email, :password, :role_id, :is_approved)";
        $stmt = $this->db->prepare($sql);

        // Instructors and Admins might need approval, students usually don't
        $is_approved = ($data['role_id'] == 3) ? 1 : 0;

        return $stmt->execute([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => password_hash($data['password'], PASSWORD_DEFAULT),
            'role_id' => $data['role_id'],
            'is_approved' => $is_approved
        ]);
    }

    public function login($email, $password)
    {
        $sql = "SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['is_blocked']) {
                return ['error' => 'Your account is blocked.'];
            }
            if (!$user['is_approved']) {
                return ['error' => 'Your account is pending approval.'];
            }
            return $user;
        }
        return false;
    }

    public function findByEmail($email)
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch();
    }
}
