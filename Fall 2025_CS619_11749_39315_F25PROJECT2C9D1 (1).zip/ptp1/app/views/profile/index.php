<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Profile Settings</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="auth-card" style="margin: 0; text-align: left; max-width: 650px; padding: 3rem;">
        <div style="display: flex; align-items: center; gap: 2rem; margin-bottom: 3rem; padding-bottom: 2rem; border-bottom: 1px solid #f1f5f9;">
            <div class="user-avatar" style="width: 100px; height: 100px; font-size: 3rem; background: linear-gradient(135deg, #2D8CFF, #0E72ED);"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
            <div>
                <h2 style="font-size: 2rem; margin-bottom: 0.5rem;"><?php echo $_SESSION['user_name']; ?></h2>
                <p style="color: var(--text-muted); font-size: 1.1rem;"><?php echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; ?></p>
                <span class="status-badge" style="margin-top: 0.75rem; display: inline-block;">Personal Account</span>
            </div>
        </div>

        <?php if (isset($data['success'])): ?>
            <div style="background: #ecfdf5; color: #059669; padding: 1rem 1.5rem; border-radius: 12px; margin-bottom: 2rem; display: flex; align-items: center; gap: 0.75rem; border: 1px solid #d1fae5;">
                <i class="fas fa-check-circle"></i> <?php echo $data['success']; ?>
            </div>
        <?php
endif; ?>

        <form action="/ptp1/public/profile/index" method="POST">
            <div style="margin-bottom: 2rem;">
                <label style="display: block; margin-bottom: 0.75rem; font-weight: 600; color: var(--text-main);">Display Name</label>
                <input type="text" name="name" class="form-input" value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>" required style="margin-bottom: 0;">
                <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.5rem;">This is the name students and colleagues will see.</p>
            </div>

            <div style="margin-bottom: 2rem;">
                <label style="display: block; margin-bottom: 0.75rem; font-weight: 600; color: var(--text-main);">Email Address</label>
                <input type="email" name="email" class="form-input" value="<?php echo htmlspecialchars(isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''); ?>" required style="margin-bottom: 0;">
                <div style="background: #eff6ff; padding: 1rem; border-radius: 12px; margin-top: 1rem; font-size: 0.85rem; color: #1e40af; display: flex; align-items: flex-start; gap: 0.75rem;">
                    <i class="fas fa-info-circle" style="margin-top: 0.2rem;"></i>
                    <span>Updating your email address will update your login credentials.</span>
                </div>
            </div>

            <div style="border-top: 1px solid #f1f5f9; padding-top: 2rem; display: flex; gap: 1.5rem;">
                <button type="submit" class="btn btn-primary" style="padding: 1rem 2.5rem; font-size: 1rem;">Save Changes</button>
                <a href="javascript:history.back()" class="btn" style="background: #f1f5f9; color: var(--primary); padding: 1rem 2.5rem; font-size: 1rem;">Discard</a>
            </div>
        </form>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
