<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Explore Courses</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="search-section" style="margin-bottom: 2rem;">
        <form action="/ptp1/public/student/browse" method="GET" style="display: flex; gap: 1rem;">
            <input type="text" name="search" class="form-input" placeholder="Search by title, category, or instructor..." value="<?php echo htmlspecialchars($data['search']); ?>" style="margin-bottom: 0; flex-grow: 1;">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>

    <div class="course-grid">
        <?php foreach ($data['courses'] as $course): ?>
            <div class="course-card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $course['title']; ?></h3>
                    <span class="status-badge" style="background: #eff6ff; color: #3b82f6;"><?php echo $course['category']; ?></span>
                </div>
                
                <div class="course-info">
                    <div class="course-icon" style="background: #f8fafc; color: #2D8CFF;">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <div class="course-details">
                        <p style="font-weight: 600;"><?php echo $course['instructor_name']; ?></p>
                        <p style="font-size: 0.85rem; color: var(--text-muted);"><?php echo $course['difficulty']; ?></p>
                    </div>
                </div>

                <div class="card-footer">
                    <div class="card-links">
                        <span><i class="fas fa-star" style="color: #f59e0b;"></i> 4.8</span>
                        <span><i class="fas fa-users"></i> 1.2k</span>
                    </div>
                    <a href="/ptp1/public/student/course/<?php echo $course['id']; ?>" class="btn btn-primary btn-small">View Details</a>
                </div>
            </div>
        <?php
endforeach; ?>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
