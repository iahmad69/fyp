<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Learning Management System</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="course-grid">
        <?php foreach ($data['enrolled_courses'] as $course): ?>
            <div class="course-card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $course['title']; ?></h3>
                    <span class="status-badge">Active</span>
                </div>
                
                <div class="course-info">
                    <div class="course-icon">
                        <i class="fas fa-laptop-code" style="color: #2D8CFF;"></i>
                    </div>
                    <div class="course-details">
                        <p><?php echo $course['category']; ?></p>
                        <p>Instructor: <?php echo $course['instructor_name']; ?></p>
                    </div>
                </div>

                <div class="progress-section">
                    <div class="progress-container">
                        <div class="progress-bar" style="width: <?php echo $course['progress']; ?>%"></div>
                    </div>
                    <p style="font-size: 0.8rem; margin-top: 0.5rem; color: var(--text-muted);"><?php echo $course['progress']; ?>% Completed</p>
                </div>

                <div class="card-footer">
                    <div class="card-links">
                        <span><i class="fas fa-folder"></i> Assignments</span>
                        <span><i class="fas fa-pen-to-square"></i> Quiz</span>
                    </div>
                    <a href="/ptp1/public/student/course/<?php echo $course['id']; ?>" class="btn btn-primary btn-small">Enter</a>
                </div>
            </div>
        <?php
endforeach; ?>

        <?php if (empty($data['enrolled_courses'])): ?>
            <div class="course-card" style="grid-column: 1/-1; text-align: center; padding: 3rem;">
                <i class="fas fa-search" style="font-size: 3rem; color: #e2e8f0; margin-bottom: 1rem;"></i>
                <p>You are not enrolled in any courses yet.</p>
                <a href="/ptp1/public/student/browse" class="btn btn-primary" style="margin-top: 1rem;">Browse Courses</a>
            </div>
        <?php
endif; ?>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
