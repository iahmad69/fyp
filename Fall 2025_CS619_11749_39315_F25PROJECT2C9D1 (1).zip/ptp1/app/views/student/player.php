<?php
$data['body_style'] = 'background: #0f172a; color: white; display: block;';
include '../app/views/layout/header.php';
$lecture = $data['lecture'];
?>

<header class="top-bar" style="background: rgba(15, 23, 42, 0.9); backdrop-filter: blur(10px); color: white; border-bottom: 1px solid rgba(255, 255, 255, 0.1); padding: 1rem 2rem; position: sticky; top: 0; z-index: 100;">
    <div style="display: flex; align-items: center; gap: 2rem;">
        <a href="/ptp1/public/student/course/<?php echo $lecture['course_id']; ?>" style="color: white; text-decoration: none; font-size: 1.25rem;"><i class="fas fa-arrow-left"></i></a>
        <div>
            <h1 style="font-size: 1.2rem; margin: 0;"><?php echo $lecture['title']; ?></h1>
            <p style="font-size: 0.8rem; opacity: 0.6; margin: 0;">Course: <?php echo $data['course']['title']; ?></p>
        </div>
    </div>
    <div class="user-profile" style="background: rgba(255, 255, 255, 0.1); color: white;">
        <span><?php echo $_SESSION['user_name']; ?></span>
        <div class="user-avatar" style="background: var(--secondary);"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
    </div>
</header>

<main style="max-width: 1200px; margin: 2rem auto; padding: 0 1rem;">
    <div class="video-container" style="background: black; border-radius: 24px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); aspect-ratio: 16/9;">
        <iframe width="100%" height="100%" src="<?php echo $lecture['video_url']; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>

    <section style="margin-top: 3rem; display: grid; grid-template-columns: 2fr 1fr; gap: 3rem;">
        <div>
            <div class="course-card" style="padding: 2.5rem; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white;">
                <h2>About this lesson</h2>
                <p style="margin-top: 1rem; opacity: 0.7; line-height: 1.6;">In this lecture, we'll dive deep into the core concepts of <?php echo $lecture['title']; ?>. Make sure to take notes and download the attached materials for a better understanding.</p>
                
                <div style="margin-top: 2rem; display: flex; gap: 1rem;">
                    <button class="btn btn-primary"><i class="fas fa-file-download"></i> Download Resources</button>
                    <button class="btn" style="background: rgba(255, 255, 255, 0.1); color: white;"><i class="fas fa-message"></i> Ask Question</button>
                </div>
            </div>
        </div>

        <div class="course-card" style="padding: 2rem; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: white;">
            <h3 style="margin-bottom: 1.5rem;"><i class="fas fa-list"></i> Course Playlist</h3>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                <?php if (!empty($data['all_lectures']) && is_array($data['all_lectures'])):
    foreach ($data['all_lectures'] as $l): ?>
                    <a href="/ptp1/public/student/play/<?php echo $l['id']; ?>" style="display: flex; align-items: center; gap: 1rem; padding: 0.75rem; border-radius: 12px; text-decoration: none; color: <?php echo($l['id'] == $lecture['id']) ? 'white' : 'rgba(255, 255, 255, 0.6)'; ?>; background: <?php echo($l['id'] == $lecture['id']) ? 'rgba(59, 130, 246, 0.2)' : 'transparent'; ?>;">
                        <i class="fas <?php echo($l['id'] == $lecture['id']) ? 'fa-play-circle text-secondary' : 'fa-circle-play'; ?>"></i>
                        <span style="font-size: 0.9rem; flex-grow: 1;"><?php echo $l['title']; ?></span>
                    </a>
                <?php
    endforeach;
endif; ?>
            </div>
        </div>
    </section>
</main>

<?php include '../app/views/layout/footer.php'; ?>
