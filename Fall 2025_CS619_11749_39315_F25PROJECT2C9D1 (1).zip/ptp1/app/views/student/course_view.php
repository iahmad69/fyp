<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<?php $course = $data['course']; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Course Overview</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
        <div class="course-card" style="padding: 2.5rem;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem;">
                <div>
                    <h2 style="font-size: 2rem; margin-bottom: 0.5rem;"><?php echo $course['title']; ?></h2>
                    <span class="status-badge" style="background: #eff6ff; color: #3b82f6;"><?php echo $course['category']; ?></span>
                </div>
                <?php if ($data['is_enrolled']): ?>
                    <span class="status-badge" style="background: #ecfdf5; color: #059669; padding: 0.75rem 1.5rem;"><i class="fas fa-check-circle"></i> Enrolled</span>
                <?php
else: ?>
                    <form action="/ptp1/public/student/enroll/<?php echo $course['id']; ?>" method="POST">
                        <button type="submit" class="btn btn-primary" style="padding: 0.75rem 2rem;">Enroll Now</button>
                    </form>
                <?php
endif; ?>
            </div>

            <p style="color: var(--text-muted); line-height: 1.8; margin-bottom: 2.5rem; font-size: 1.1rem;"><?php echo $course['description']; ?></p>

            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; padding-top: 2rem; border-top: 1px solid #f1f5f9;">
                <div>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.25rem;">Difficulty</p>
                    <p style="font-weight: 600;"><i class="fas fa-signal" style="color: #2D8CFF;"></i> <?php echo $course['difficulty']; ?></p>
                </div>
                <div>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.25rem;">Instructor</p>
                    <p style="font-weight: 600;"><i class="fas fa-user-tie" style="color: #2D8CFF;"></i> <?php echo $course['instructor_name']; ?></p>
                </div>
                <div>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.25rem;">Last Updated</p>
                    <p style="font-weight: 600;"><i class="fas fa-calendar-alt" style="color: #2D8CFF;"></i> Oct 2023</p>
                </div>
            </div>
        </div>

        <aside>
            <div class="course-card" style="padding: 1.5rem; margin-bottom: 2rem;">
                <h3 style="margin-bottom: 1.5rem;"><i class="fas fa-play-circle"></i> Lectures (<?php echo count($data['lectures']); ?>)</h3>
                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                    <?php foreach ($data['lectures'] as $lecture): ?>
                        <?php if ($data['is_enrolled']): ?>
                            <a href="/ptp1/public/student/play/<?php echo $lecture['id']; ?>" class="sidebar-link" style="border-radius: 12px; background: #f8fafc; margin: 0; padding: 1rem;">
                                <i class="fas fa-circle-play"></i> <?php echo $lecture['title']; ?>
                            </a>
                        <?php
    else: ?>
                            <div style="display: flex; align-items: center; gap: 0.75rem; padding: 1rem; border-radius: 12px; background: #f1f5f9; cursor: not-allowed; opacity: 0.7;">
                                <i class="fas fa-lock"></i> <?php echo $lecture['title']; ?>
                            </div>
                        <?php
    endif; ?>
                    <?php
endforeach; ?>
                </div>
            </div>

            <div class="course-card" style="padding: 1.5rem;">
                <h3 style="margin-bottom: 1.5rem;"><i class="fas fa-file-alt"></i> Materials</h3>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <?php foreach ($data['materials'] as $material): ?>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <i class="fas fa-file-pdf" style="color: #ef4444; font-size: 1.25rem;"></i>
                            <span style="font-size: 0.9rem;"><?php echo $material['title']; ?></span>
                        </div>
                    <?php
endforeach; ?>
                </div>
            </div>
        </aside>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
