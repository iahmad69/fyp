<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - LMS Portal</title>
    <link rel="stylesheet" href="/ptp1/public/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body style="display: block;">
    <header class="top-bar" style="max-width: 1200px; margin: 1rem auto; background: white; border-radius: 100px; padding: 0.75rem 2rem; box-shadow: var(--card-shadow);">
        <div class="sidebar-brand" style="margin-bottom: 0; color: var(--primary);">
            <i class="fas fa-graduation-cap text-secondary"></i>
            <span>LMS Portal</span>
        </div>
        <nav style="display: flex; gap: 2rem; align-items: center;">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="/ptp1/public/auth/logout" style="text-decoration: none; color: var(--text-muted); font-weight: 500;">Logout</a>
                <a href="/ptp1/public/<?php echo strtolower($_SESSION['role_name']); ?>/dashboard" class="btn btn-primary btn-small">Dashboard</a>
            <?php
else: ?>
                <a href="/ptp1/public/auth/login" style="text-decoration: none; color: var(--text-muted); font-weight: 500;">Sign In</a>
                <a href="/ptp1/public/auth/register" class="btn btn-primary btn-small">Join Free</a>
            <?php
endif; ?>
        </nav>
    </header>

    <main style="max-width: 1200px; margin: 4rem auto; padding: 0 2rem; text-align: center;">
        <section style="margin-bottom: 6rem;">
            <span style="background: #eff6ff; color: #3b82f6; padding: 0.5rem 1.25rem; border-radius: 50px; font-weight: 600; font-size: 0.85rem; letter-spacing: 0.05em; text-transform: uppercase;">Final Project Prototype</span>
            <h1 style="font-size: 4.5rem; font-weight: 800; margin-top: 1.5rem; line-height: 1.1; color: var(--primary);">Master New Skills <br> <span style="color: var(--secondary);">Anytime, Anywhere.</span></h1>
            <p style="font-size: 1.25rem; color: var(--text-muted); max-width: 700px; margin: 2rem auto;">A complete E-Learning platform designed for seamless course sharing and progress tracking. Start your journey today.</p>
            
            <div style="display: flex; gap: 1.5rem; justify-content: center; margin-top: 3rem;">
                <a href="/ptp1/public/auth/register" class="btn btn-primary" style="padding: 1.25rem 2.5rem; font-size: 1.1rem;">Get Started Now <i class="fas fa-arrow-right"></i></a>
                <a href="/ptp1/public/student/browse" class="btn" style="padding: 1.25rem 2.5rem; font-size: 1.1rem; background: var(--white); border: 1px solid #e2e8f0; color: var(--primary);">Explore Courses</a>
            </div>
        </section>

        <section style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2.5rem;">
            <div class="course-card" style="padding: 3rem;">
                <div class="course-icon" style="margin: 0 auto 1.5rem; width: 70px; height: 70px; background: #fee2e2; color: #ef4444;"><i class="fas fa-user-graduate"></i></div>
                <h3>For Students</h3>
                <p style="color: var(--text-muted); margin-top: 1rem;">Enroll in high-quality courses and track your progress with ease.</p>
            </div>
            <div class="course-card" style="padding: 3rem;">
                <div class="course-icon" style="margin: 0 auto 1.5rem; width: 70px; height: 70px; background: #dcfce7; color: #10b981;"><i class="fas fa-chalkboard-teacher"></i></div>
                <h3>For Instructors</h3>
                <p style="color: var(--text-muted); margin-top: 1rem;">Share your knowledge with the world using our powerful course tools.</p>
            </div>
            <div class="course-card" style="padding: 3rem;">
                <div class="course-icon" style="margin: 0 auto 1.5rem; width: 70px; height: 70px; background: #e0e7ff; color: #6366f1;"><i class="fas fa-user-shield"></i></div>
                <h3>For Admins</h3>
                <p style="color: var(--text-muted); margin-top: 1rem;">Full control over users, courses, and platform statistics.</p>
            </div>
        </section>
    </main>

    <footer style="background: transparent; border-top: 1px solid #e2e8f0; color: var(--text-muted); padding: 4rem 2rem;">
        <p>© 2026 LMS Portal. Built for Ahmad's CS619 Final Project.</p>
    </footer>
</body>
</html>
