<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">User Management</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="course-card" style="padding: 0; overflow: hidden; margin-top: 1rem;">
        <div class="card-header" style="padding: 1.5rem; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center;">
            <h3 class="card-title">All Users</h3>
            <a href="/ptp1/public/admin/add_user" class="btn btn-primary btn-small"><i class="fas fa-plus"></i> Add User</a>
        </div>
        <table style="width: 100%; border-collapse: collapse; text-align: left;">
            <thead>
                <tr style="background: #f8fafc; border-bottom: 1px solid #f1f5f9;">
                    <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Name</th>
                    <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Email</th>
                    <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Role</th>
                    <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Status</th>
                    <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['users'] as $user): ?>
                    <tr style="border-bottom: 1px solid #f1f5f9;">
                        <td style="padding: 1.25rem 1.5rem; font-weight: 500;"><?php echo $user['name']; ?></td>
                        <td style="padding: 1.25rem 1.5rem; font-size: 0.9rem; color: var(--text-muted);"><?php echo $user['email']; ?></td>
                        <td style="padding: 1.25rem 1.5rem;">
                            <span class="status-badge" style="background: <?php echo($user['role_name'] == 'Admin') ? '#eff6ff' : (($user['role_name'] == 'Instructor') ? '#fdf2f7' : '#f0fdf4'); ?>; color: <?php echo($user['role_name'] == 'Admin') ? '#3b82f6' : (($user['role_name'] == 'Instructor') ? '#db2777' : '#16a34a'); ?>;">
                                <?php echo $user['role_name']; ?>
                            </span>
                        </td>
                        <td style="padding: 1.25rem 1.5rem;">
                            <?php if ($user['is_blocked']): ?>
                                <span class="status-badge" style="background: #fef2f2; color: #ef4444;">Blocked</span>
                            <?php
    elseif ($user['role_name'] == 'Instructor' && !$user['is_approved']): ?>
                                <span class="status-badge" style="background: #fffbeb; color: #d97706;">Pending</span>
                            <?php
    else: ?>
                                <span class="status-badge" style="background: #f0fdf4; color: #16a34a;">Active</span>
                            <?php
    endif; ?>
                        </td>
                        <td style="padding: 1.25rem 1.5rem; display: flex; gap: 0.5rem;">
                            <?php if ($user['role_name'] == 'Instructor' && !$user['is_approved']): ?>
                                <a href="/ptp1/public/admin/approve/<?php echo $user['id']; ?>" class="btn btn-small" style="background: #10b981; color: white;"><i class="fas fa-check"></i></a>
                            <?php
    endif; ?>
                            
                            <?php if ($user['is_blocked']): ?>
                                <a href="/ptp1/public/admin/unblock/<?php echo $user['id']; ?>" class="btn btn-small" style="background: #f1f5f9; color: var(--text-muted);"><i class="fas fa-unlock"></i></a>
                            <?php
    elseif ($user['id'] != $_SESSION['user_id']): ?>
                                <a href="/ptp1/public/admin/block/<?php echo $user['id']; ?>" class="btn btn-small" style="background: #f1f5f9; color: var(--text-muted);"><i class="fas fa-ban"></i></a>
                            <?php
    endif; ?>
                        </td>
                    </tr>
                <?php
endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
