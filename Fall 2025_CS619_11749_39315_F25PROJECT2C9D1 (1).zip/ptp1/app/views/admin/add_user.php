<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Add New User</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="auth-card" style="margin: 0; text-align: left; max-width: 600px; padding: 3rem;">
        <?php if (isset($data['error'])): ?>
            <div class="error" style="margin-bottom: 1.5rem;"><i class="fas fa-exclamation-circle"></i> <?php echo $data['error']; ?></div>
        <?php
endif; ?>

        <form action="/ptp1/public/admin/add_user" method="POST">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" class="form-input" placeholder="Enter user's full name" required>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-input" placeholder="Enter user's email" required>
            </div>

            <div class="form-group">
                <label>Temporary Password</label>
                <input type="password" name="password" class="form-input" placeholder="Create a temporary password" required>
            </div>

            <div class="form-group">
                <label>System Role</label>
                <select name="role_id" class="form-input" required>
                    <option value="3">Student</option>
                    <option value="2">Instructor</option>
                    <option value="1">Admin</option>
                </select>
            </div>

            <div style="background: #f8fafc; padding: 1.25rem; border-radius: 12px; margin-bottom: 2rem; font-size: 0.85rem; color: var(--text-muted);">
                <i class="fas fa-info-circle"></i> Users added by admins are automatically approved and can log in immediately.
            </div>

            <div class="form-actions" style="display: flex; gap: 1rem;">
                <button type="submit" class="btn btn-primary" style="flex-grow: 1;">Create Account</button>
                <a href="/ptp1/public/admin/users" class="btn" style="background: #f1f5f9; color: var(--primary);">Cancel</a>
            </div>
        </form>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
