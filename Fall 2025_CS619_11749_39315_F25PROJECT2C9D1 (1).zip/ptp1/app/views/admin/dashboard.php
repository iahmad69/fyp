<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Platform Overview</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="stat-grid">
        <div class="stat-item stat-primary">
            <div class="stat-header">
                <span class="stat-label">Total Users</span>
                <span class="stat-badge">System</span>
            </div>
            <div class="stat-body">
                <div class="stat-icon-box"><i class="fas fa-users"></i></div>
                <span class="stat-value"><?php echo $data['stats']['total_users']; ?></span>
            </div>
            <div class="stat-footer">
                <span style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-user-check" style="color: #3b82f6;"></i> Active</span>
                <a href="/ptp1/public/admin/users" class="btn btn-primary btn-small">Manage</a>
            </div>
        </div>

        <div class="stat-item stat-success">
            <div class="stat-header">
                <span class="stat-label">Instructors</span>
                <span class="stat-badge">Faculty</span>
            </div>
            <div class="stat-body">
                <div class="stat-icon-box"><i class="fas fa-chalkboard-teacher"></i></div>
                <span class="stat-value"><?php echo $data['stats']['total_instructors']; ?></span>
            </div>
            <div class="stat-footer">
                <span style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-check-circle" style="color: #22c55e;"></i> Verified</span>
                <a href="/ptp1/public/admin/users" class="btn btn-primary btn-small">Manage</a>
            </div>
        </div>

        <div class="stat-item stat-indigo">
            <div class="stat-header">
                <span class="stat-label">Total Courses</span>
                <span class="stat-badge">Catalog</span>
            </div>
            <div class="stat-body">
                <div class="stat-icon-box"><i class="fas fa-book"></i></div>
                <span class="stat-value"><?php echo $data['stats']['total_courses']; ?></span>
            </div>
            <div class="stat-footer">
                <span style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-layer-group" style="color: #6366f1;"></i> Published</span>
                <a href="/ptp1/public/admin/dashboard" class="btn btn-primary btn-small">View All</a>
            </div>
        </div>

        <div class="stat-item stat-warning">
            <div class="stat-header">
                <span class="stat-label">Pending Approval</span>
                <span class="stat-badge">Queue</span>
            </div>
            <div class="stat-body">
                <div class="stat-icon-box"><i class="fas fa-clock"></i></div>
                <span class="stat-value"><?php echo $data['stats']['pending_instructors']; ?></span>
            </div>
            <div class="stat-footer">
                <span style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-exclamation-triangle" style="color: #f59e0b;"></i> Action Required</span>
                <a href="/ptp1/public/admin/users" class="btn btn-primary btn-small">Review</a>
            </div>
        </div>
    </div>

    <div class="course-grid">
        <div class="course-card" style="grid-column: 1/-1; padding: 2rem;">
            <h3 style="margin-bottom: 1.5rem;">Quick Actions</h3>
            <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                <a href="/ptp1/public/admin/users" class="btn btn-primary"><i class="fas fa-user-shield"></i> Manage Roles</a>
                <a href="/ptp1/public/admin/add_user" class="btn" style="background: #f1f5f9; color: var(--primary);"><i class="fas fa-user-plus"></i> Add User</a>
                <button class="btn" style="background: #f1f5f9; color: var(--primary);"><i class="fas fa-cog"></i> System Settings</button>
            </div>
        </div>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
