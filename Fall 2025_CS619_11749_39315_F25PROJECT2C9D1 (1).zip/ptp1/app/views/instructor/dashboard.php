<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Instructor Dashboard</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="stat-grid">
        <div class="stat-item stat-indigo">
            <div class="stat-header">
                <span class="stat-label">Total Courses</span>
                <span class="stat-badge">Instructor</span>
            </div>
            <div class="stat-body">
                <div class="stat-icon-box"><i class="fas fa-book-open"></i></div>
                <span class="stat-value"><?php echo is_array($data['courses']) ? count($data['courses']) : 0; ?></span>
            </div>
            <div class="stat-footer">
                <span style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-check-circle" style="color: #6366f1;"></i> Active Courses</span>
                <a href="/ptp1/public/instructor/create" class="btn btn-primary btn-small">Add New</a>
            </div>
        </div>
    </div>

    <div class="course-grid">
        <div class="course-card" style="grid-column: 1/-1; padding: 0; overflow: hidden;">
            <div class="card-header" style="padding: 1.5rem; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center;">
                <h3 class="card-title">My Courses</h3>
                <a href="/ptp1/public/instructor/create" class="btn btn-primary btn-small"><i class="fas fa-plus"></i> New Course</a>
            </div>
            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="background: #f8fafc; border-bottom: 1px solid #f1f5f9;">
                        <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Title</th>
                        <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Category</th>
                        <th style="padding: 1rem 1.5rem; font-weight: 600; color: var(--text-muted);">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['courses'] as $course): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 1.25rem 1.5rem; font-weight: 500;"><?php echo $course['title']; ?></td>
                            <td style="padding: 1.25rem 1.5rem; color: var(--text-muted);"><?php echo $course['category']; ?></td>
                            <td style="padding: 1.25rem 1.5rem; display: flex; gap: 0.75rem;">
                                <a href="/ptp1/public/instructor/lectures/<?php echo $course['id']; ?>" class="btn btn-small" style="background: #f1f5f9; color: var(--primary);"><i class="fas fa-video"></i></a>
                                <a href="/ptp1/public/instructor/edit/<?php echo $course['id']; ?>" class="btn btn-small" style="background: #f1f5f9; color: var(--primary);"><i class="fas fa-edit"></i></a>
                                <a href="/ptp1/public/instructor/delete/<?php echo $course['id']; ?>" class="btn btn-small" style="background: #fef2f2; color: #ef4444;" onclick="return confirm('Delete this course?')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php
endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
