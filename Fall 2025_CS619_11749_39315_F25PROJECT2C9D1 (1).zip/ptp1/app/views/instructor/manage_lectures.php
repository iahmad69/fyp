<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Manage Lectures</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div style="display: grid; grid-template-columns: 1fr 1.5fr; gap: 2rem;">
        <div class="course-card" style="padding: 2.5rem;">
            <h3 style="margin-bottom: 2rem;"><i class="fas fa-plus-circle"></i> Add New Lecture</h3>
            <form action="/ptp1/public/instructor/lectures/<?php echo $data['course_id']; ?>" method="POST">
                <div class="form-group">
                    <label>Lecture Title</label>
                    <input type="text" name="title" class="form-input" placeholder="e.g. Introduction to Variables" required>
                </div>
                <div class="form-group">
                    <label>YouTube Video URL</label>
                    <input type="url" name="video_url" class="form-input" placeholder="https://www.youtube.com/embed/..." required>
                </div>
                <div class="form-group">
                    <label>Order Number</label>
                    <input type="number" name="order_num" class="form-input" value="<?php echo count($data['lectures']) + 1; ?>" required>
                </div>
                <button type="submit" name="add_lecture" class="btn btn-primary" style="width: 100%; padding: 1rem;">Add Lecture</button>
            </form>
        </div>

        <div class="course-card" style="padding: 0; overflow: hidden;">
            <div class="card-header" style="padding: 1.5rem; border-bottom: 1px solid #f1f5f9;">
                <h3 class="card-title">Existing Lectures</h3>
            </div>
            <div style="padding: 1.5rem;">
                <?php foreach ($data['lectures'] as $lecture): ?>
                    <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; border-radius: 12px; border: 1px solid #f1f5f9; margin-bottom: 0.75rem; background: #f8fafc;">
                        <span style="font-weight: 700; color: var(--primary); width: 30px;"><?php echo $lecture['order_num']; ?>.</span>
                        <div style="flex-grow: 1;">
                            <h4 style="margin: 0; font-size: 0.95rem;"><?php echo $lecture['title']; ?></h4>
                            <p style="margin: 4px 0 0; font-size: 0.8rem; color: var(--text-muted);"><?php echo $lecture['video_url']; ?></p>
                        </div>
                        <button class="btn btn-small" style="background: #fee2e2; color: #ef4444;"><i class="fas fa-times"></i></button>
                    </div>
                <?php
endforeach; ?>
                
                <?php if (empty($data['lectures'])): ?>
                    <div style="text-align: center; padding: 3rem; color: var(--text-muted);">
                        <i class="fas fa-film" style="font-size: 3rem; opacity: 0.2; margin-bottom: 1rem;"></i>
                        <p>No lectures added yet. Start by using the form on the left.</p>
                    </div>
                <?php
endif; ?>
            </div>
        </div>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
