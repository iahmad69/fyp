<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Manage Materials</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div style="display: grid; grid-template-columns: 1fr 1.5fr; gap: 2rem;">
        <div class="course-card" style="padding: 2.5rem;">
            <h3 style="margin-bottom: 2rem;"><i class="fas fa-plus-circle"></i> Add Learning Material</h3>
            <form action="/ptp1/public/instructor/materials/<?php echo $data['course_id']; ?>" method="POST">
                <div class="form-group">
                    <label>Material Title</label>
                    <input type="text" name="title" class="form-input" placeholder="e.g. Course Syllabus PDF" required>
                </div>
                <div class="form-group">
                    <label>File Path or Link</label>
                    <input type="text" name="file_path" class="form-input" placeholder="e.g. /materials/syllabus.pdf" required>
                </div>
                <button type="submit" name="add_material" class="btn btn-primary" style="width: 100%; padding: 1rem;">Add Material</button>
            </form>
        </div>

        <div class="course-card" style="padding: 0; overflow: hidden;">
            <div class="card-header" style="padding: 1.5rem; border-bottom: 1px solid #f1f5f9;">
                <h3 class="card-title">Attached Materials</h3>
            </div>
            <div style="padding: 1.5rem;">
                <?php foreach ($data['materials'] as $material): ?>
                    <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; border-radius: 12px; border: 1px solid #f1f5f9; margin-bottom: 0.75rem; background: #f8fafc;">
                        <i class="fas fa-file-pdf" style="color: #ef4444; font-size: 1.25rem;"></i>
                        <div style="flex-grow: 1;">
                            <h4 style="margin: 0; font-size: 0.95rem;"><?php echo $material['title']; ?></h4>
                            <p style="margin: 4px 0 0; font-size: 0.8rem; color: var(--text-muted);"><?php echo $material['file_path']; ?></p>
                        </div>
                        <button class="btn btn-small" style="background: #fee2e2; color: #ef4444;"><i class="fas fa-times"></i></button>
                    </div>
                <?php
endforeach; ?>
                
                <?php if (empty($data['materials'])): ?>
                    <div style="text-align: center; padding: 3rem; color: var(--text-muted);">
                        <i class="fas fa-file-circle-plus" style="font-size: 3rem; opacity: 0.2; margin-bottom: 1rem;"></i>
                        <p>No materials uploaded yet.</p>
                    </div>
                <?php
endif; ?>
            </div>
        </div>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
