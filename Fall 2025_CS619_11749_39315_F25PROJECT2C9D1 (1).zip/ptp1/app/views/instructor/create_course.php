<?php include '../app/views/layout/header.php'; ?>
<?php include '../app/views/layout/sidebar.php'; ?>

<main class="main-wrapper">
    <header class="top-bar">
        <div style="display: flex; align-items: center;">
            <div class="mobile-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </div>
            <h1 class="page-title">Create New Course</h1>
        </div>
        <div class="user-profile">
            <span class="user-name"><?php echo $_SESSION['user_name']; ?></span>
            <div class="user-avatar"><?php echo substr($_SESSION['user_name'], 0, 1); ?></div>
        </div>
    </header>

    <div class="auth-card" style="margin: 0; text-align: left; max-width: 800px; padding: 3rem;">
        <form action="/ptp1/public/instructor/create" method="POST">
            <div class="form-group">
                <label>Course Title</label>
                <input type="text" name="title" class="form-input" placeholder="e.g. Advanced PHP Development" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                <div class="form-group">
                    <label>Category</label>
                    <select name="category" class="form-input" required>
                        <option value="Programming">Programming</option>
                        <option value="Web Design">Web Design</option>
                        <option value="Data Science">Data Science</option>
                        <option value="Business">Business</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Difficulty</label>
                    <select name="difficulty" class="form-input" required>
                        <option value="Beginner">Beginner</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Advanced">Advanced</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Course Description</label>
                <textarea name="description" class="form-input" rows="5" placeholder="Describe what students will learn..." required style="resize: vertical;"></textarea>
            </div>

            <div class="form-actions" style="display: flex; gap: 1rem; padding-top: 1.5rem; border-top: 1px solid #f1f5f9;">
                <button type="submit" class="btn btn-primary" style="padding: 1rem 2.5rem;">Create Course</button>
                <a href="/ptp1/public/instructor/dashboard" class="btn" style="background: #f1f5f9; color: var(--primary); padding: 1rem 2.5rem;">Cancel</a>
            </div>
        </form>
    </div>
</main>

<?php include '../app/views/layout/footer.php'; ?>
