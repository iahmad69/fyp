<?php
$data['body_class'] = 'auth-body';
include '../app/views/layout/header.php';
?>

<div class="auth-card" style="max-width: 500px;">
    <div class="sidebar-brand" style="justify-content: center; margin-bottom: 2rem; color: var(--primary);">
        <i class="fas fa-graduation-cap text-secondary" style="color: #2D8CFF;"></i>
        <span>LMS Portal</span>
    </div>
    <h2 class="auth-title">Create Account</h2>
    <p class="auth-subtitle">Join thousands of students learning today</p>

    <form action="/ptp1/public/auth/register" method="POST">
        <div style="text-align: left; margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem;">Full Name</div>
        <input type="text" name="name" class="form-input" placeholder="Enter your name" required>

        <div style="text-align: left; margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem;">Email Address</div>
        <input type="email" name="email" class="form-input" placeholder="user@example.com" required>
        
        <div style="text-align: left; margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem;">Password</div>
        <input type="password" name="password" class="form-input" placeholder="At least 8 characters" required>
        
        <div style="text-align: left; margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem;">Join as</div>
        <select name="role_id" class="form-input" required>
            <option value="3">Student (Learning)</option>
            <option value="2">Instructor (Teaching)</option>
        </select>

        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem; padding: 1rem;">
            Register Now <i class="fas fa-user-plus"></i>
        </button>
    </form>

    <p style="margin-top: 2rem; font-size: 0.9rem; color: var(--text-muted);">
        Already have an account? <a href="/ptp1/public/auth/login" style="color: var(--secondary); font-weight: 600; text-decoration: none;">Sign in here</a>
    </p>
</div>

<?php include '../app/views/layout/footer.php'; ?>
