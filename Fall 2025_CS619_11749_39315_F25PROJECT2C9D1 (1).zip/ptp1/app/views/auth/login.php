<?php
$data['body_class'] = 'auth-body';
include '../app/views/layout/header.php';
?>

<div class="auth-card">
    <div class="sidebar-brand" style="justify-content: center; margin-bottom: 2rem; color: var(--primary);">
        <i class="fas fa-graduation-cap text-secondary" style="color: #2D8CFF;"></i>
        <span>LMS Portal</span>
    </div>
    <h2 class="auth-title">Welcome Back</h2>
    <p class="auth-subtitle">Login to your account to continue</p>

    <?php if (isset($data['error'])): ?>
        <div class="error" style="font-size: 0.9rem; padding: 0.75rem; border-radius: 12px; margin-bottom: 1.5rem;">
            <i class="fas fa-exclamation-circle"></i> <?php echo $data['error']; ?>
        </div>
    <?php
endif; ?>

    <?php if (isset($_GET['registered'])): ?>
        <div class="success" style="font-size: 0.9rem; padding: 0.75rem; border-radius: 12px; margin-bottom: 1.5rem;">
            <i class="fas fa-check-circle"></i> Registration successful. Please login.
        </div>
    <?php
endif; ?>

    <form action="/ptp1/public/auth/login" method="POST">
        <div style="text-align: left; margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem;">Email Address</div>
        <input type="email" name="email" class="form-input" placeholder="e.g. user@example.com" required>
        
        <div style="text-align: left; margin-bottom: 0.5rem; font-weight: 500; font-size: 0.9rem;">Password</div>
        <input type="password" name="password" class="form-input" placeholder="••••••••" required>
        
        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem; padding: 1rem;">
            Login to Dashboard <i class="fas fa-arrow-right"></i>
        </button>
    </form>

    <p style="margin-top: 2rem; font-size: 0.9rem; color: var(--text-muted);">
        Don't have an account? <a href="/ptp1/public/auth/register" style="color: var(--secondary); font-weight: 600; text-decoration: none;">Create one free</a>
    </p>
</div>

<?php include '../app/views/layout/footer.php'; ?>
