    <aside class="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-graduation-cap text-secondary" style="color: #2D8CFF;"></i>
            <span>LMS Portal</span>
        </div>
        <ul class="sidebar-menu">
            <?php if ($_SESSION['user_role'] == 'Student'): ?>
                <li><a href="/ptp1/public/student/dashboard" class="sidebar-link"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="/ptp1/public/student/browse" class="sidebar-link"><i class="fas fa-layer-group"></i> Browse Courses</a></li>
            <?php
elseif ($_SESSION['user_role'] == 'Instructor'): ?>
                <li><a href="/ptp1/public/instructor/dashboard" class="sidebar-link"><i class="fas fa-chart-line"></i> Dashboard</a></li>
                <li><a href="/ptp1/public/instructor/create" class="sidebar-link"><i class="fas fa-plus-circle"></i> Create Course</a></li>
            <?php
elseif ($_SESSION['user_role'] == 'Admin'): ?>
                <li><a href="/ptp1/public/admin/dashboard" class="sidebar-link"><i class="fas fa-chart-pie"></i> Statistics</a></li>
                <li><a href="/ptp1/public/admin/users" class="sidebar-link"><i class="fas fa-users-cog"></i> User Management</a></li>
            <?php
endif; ?>
            <li><a href="/ptp1/public/profile/index" class="sidebar-link"><i class="fas fa-user-circle"></i> My Profile</a></li>
        </ul>
        <div class="sidebar-footer" style="margin-top: auto; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.05);">
            <a href="/ptp1/public/auth/logout" class="sidebar-link" style="flex-direction: row; gap: 1rem; width: 100%;"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>
