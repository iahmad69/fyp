<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $data['title']; ?> - LMS Portal</title>
    <link rel="stylesheet" href="/ptp1/public/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="/ptp1/public/js/main.js" defer></script>
<body class="<?php echo isset($data['body_class']) ? $data['body_class'] : ''; ?>" style="<?php echo isset($data['body_style']) ? $data['body_style'] : ''; ?>">
