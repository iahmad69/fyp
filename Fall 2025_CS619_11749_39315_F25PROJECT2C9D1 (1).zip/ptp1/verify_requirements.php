<?php
$db = new PDO('mysql:host=localhost;dbname=elearning_db', 'root', '');

$courses = $db->query("SELECT id, title FROM courses")->fetchAll(PDO::FETCH_ASSOC);
echo "Total Courses: " . count($courses) . "\n";

foreach ($courses as $c) {
    $lectures = $db->prepare("SELECT COUNT(*) FROM lectures WHERE course_id = ?");
    $lectures->execute([$c['id']]);
    $l_count = $lectures->fetchColumn();

    $materials = $db->prepare("SELECT COUNT(*) FROM materials WHERE course_id = ?");
    $materials->execute([$c['id']]);
    $m_count = $materials->fetchColumn();

    echo " - " . $c['title'] . ": $l_count Lectures, $m_count Materials\n";
}
