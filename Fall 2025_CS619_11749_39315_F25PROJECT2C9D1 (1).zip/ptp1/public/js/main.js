/**
 * Global JavaScript for E-Learning Platform
 * Handles sidebar toggling, mobile responsiveness, and common UI interactions.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Sidebar Toggle Logic
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.querySelector('.sidebar');

    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 992 &&
                sidebar.classList.contains('active') &&
                !sidebar.contains(e.target) &&
                !menuToggle.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });
    }

    // Smooth entry animations for cards
    const cards = document.querySelectorAll('.course-card, .stat-item');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.4s ease-out';

        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100 * index);
    });

    // Handle active state for sidebar links based on current URL
    const currentPath = window.location.pathname;
    const sidebarLinks = document.querySelectorAll('.sidebar-link');

    sidebarLinks.forEach(link => {
        if (link.getAttribute('href') && currentPath.includes(link.getAttribute('href'))) {
            // Remove active class from all first
            sidebarLinks.forEach(l => l.classList.remove('active'));
            // Add to current
            link.classList.add('active');
        }
    });

    // Form input focus effects
    const formInputs = document.querySelectorAll('.form-input');
    formInputs.forEach(input => {
        input.addEventListener('focus', () => {
            const group = input.closest('.form-group');
            if (group) group.classList.add('focused');
        });
        input.addEventListener('blur', () => {
            const group = input.closest('.form-group');
            if (group) group.classList.remove('focused');
        });
    });
});
